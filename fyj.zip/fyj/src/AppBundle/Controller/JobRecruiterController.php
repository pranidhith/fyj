<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\JobRecruiter;
use Symfony\Component\Validator\Constraints\DateTime;


use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;


class JobRecruiterController extends Controller
{
    /**
     * @Route("/jobrecruiter/", name="jobRecruiter_home")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
       return $this->redirectToRoute('jobRecruiter_viewAll');
    }


    /**
     * @Route("/jobrecruiter/create", name="jobRecruiter_create")
     */
    public function createAction(Request $request)
    {
        $jobRecruiter = new JobRecruiter();

        $jobRecruiter->setAccCreatedDate(new \DateTime('now'));
        $jobRecruiter->setaccLastAccessedDate(new \DateTime('now'));
        $jobRecruiter->setLatitude(21241.323);
        $jobRecruiter->setLongitude(35235.325);

        $form = $this->createFormBuilder($jobRecruiter)
            ->add('name', TextType::class)
            ->add('companyName', TextType::class)
            ->add('companyAddress', TextType::class)
            ->add('emailAddress', EmailType::class)
            ->add('linkedInURL', UrlType::class)
            ->add('username', TextType::class)
            ->add('password', RepeatedType::class, array(
                'type' => PasswordType::class,
                'invalid_message' => 'The password fields must match.',
                'options' => array('attr' => array('class' => 'password-field')),
                'required' => true,
                'first_options'  => array('label' => 'Password'),
                'second_options' => array('label' => 'Repeat Password'),
            ))
            ->add('save', SubmitType::class, array('label' => 'Create Account'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid() ) {
            // ... perform some action, such as saving the task to the database
     
            $em = $this->getDoctrine()->getManager();

            $em->persist($jobRecruiter);
            $em->flush();

            return $this->redirectToRoute("jobRecruiter_home");
        }

        // replace this example code with whatever you need
        return $this->render('jobrecruiter/create.html.twig', array('form' => $form->createView()));
    }

    /**
     * @Route("/jobrecruiter/view/{id}", name="jobRecruiter_view")
     */
    public function viewAction($id, Request $request)
    {
        
        $jobRecruiter = $this->getDoctrine()
            ->getRepository('AppBundle:JobRecruiter')
            ->find($id);

        if (!$jobRecruiter) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return $this->render('jobrecruiter/view.html.twig', array('jobRecruiter'=> $jobRecruiter));  

    }

    /**
     * @Route("/jobrecruiter/view", name="jobRecruiter_viewAll")
     */
    public function viewallAction( Request $request)
    {
        $createdDates = array();
        $lastDates = array();
        $repository = $this->getDoctrine()
            ->getRepository('AppBundle:JobRecruiter');
        $jobRecruiters = $repository->findAll();

        return $this->render('jobrecruiter/viewall.html.twig', array('jobRecruiters' => $jobRecruiters));

    }

    /**
     * @Route("/jobrecruiter/update/{id}", name="jobRecruiter_update")
     */
    public function updateAction( $id,Request $request)
    {
       
        $em = $this->getDoctrine()->getManager();
        $jobRecruiter = $em->getRepository('AppBundle:JobRecruiter')->find($id);

        $form = $this->createFormBuilder($jobRecruiter)
            ->add('name', TextType::class)
            ->add('companyName', TextType::class)
            ->add('companyAddress', TextType::class)
            ->add('emailAddress', EmailType::class)
            ->add('linkedInURL', UrlType::class)
            ->add('save', SubmitType::class, array('label' => 'Create Account'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // ... perform some action, such as saving the task to the database
            $em->flush();

            return $this->redirectToRoute('jobRecruiter_viewAll');
        }

        // replace this example code with whatever you need
        return $this->render('jobRecruiter/update.html.twig', array('form' => $form->createView()));
    }

    /**
     * @Route("/jobrecruiter/linkedin/{id}", name="jobRecruiter_linkedin")
     */
    public function linkedInAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $jobRecruiter = $em->getRepository('AppBundle:JobRecruiter')->find($id);

        $url = $jobRecruiter->getLinkedInURL();

        return $this->redirect($url);
    }
 
}
