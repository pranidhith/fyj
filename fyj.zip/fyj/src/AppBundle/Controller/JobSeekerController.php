<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\JobSeeker;
use Symfony\Component\Validator\Constraints\DateTime;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;


class JobSeekerController extends Controller
{
    /**
     * @Route("/jobseeker/", name="jobSeeker_home")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->redirectToRoute('jobSeeker_viewAll');
    }


    /**
     * @Route("/jobseeker/create", name="jobSeeker_create")
     */
    public function createAction(Request $request)
    {
        $jobSeeker = new JobSeeker();

        $fields = $this->getDoctrine()
            ->getRepository('AppBundle:Field')
            ->findAll();

        $fieldIds = array();

        foreach ($fields as $field) {
            $fieldIds[$field->getName()] = $field;
        }
        

        $jobSeeker->setAccCreatedDate(new \DateTime('now'));
        $jobSeeker->setaccLastAccessedDate(new \DateTime('now'));

        $form = $this->createFormBuilder($jobSeeker)
            ->add('name', TextType::class)
            ->add('expectedSalary', IntegerType::class)
            ->add('emailAddress', EmailType::class)
            ->add('linkedInURL', UrlType::class)
            ->add('jobSeekerField',ChoiceType::class, array(
                'choices'  => $fieldIds,
                'choices_as_values' => true,
                'label'=>'Preferred Field'
            ))
            ->add('username', TextType::class)
            ->add('password', RepeatedType::class, array(
                'type' => PasswordType::class,
                'invalid_message' => 'The password fields must match.',
                'options' => array('attr' => array('class' => 'password-field')),
                'required' => true,
                'first_options'  => array('label' => 'Password'),
                'second_options' => array('label' => 'Repeat Password'),
            ))
            ->add('save', SubmitType::class, array('label' => 'Create Account'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid() ) {
            // ... perform some action, such as saving the task to the database
     
            $em = $this->getDoctrine()->getManager();

            $em->persist($jobSeeker);
            $em->flush();

            return $this->redirectToRoute("jobSeeker_home");
        }

       

        // replace this example code with whatever you need
        return $this->render('jobseeker/create.html.twig', array('form' => $form->createView()));
    }

    /**
     * @Route("/jobseeker/view/{id}", name="jobSeeker_view")
     */
    public function viewAction($id, Request $request)
    {
        //$jobSeeker =  JobSeeker::getOne($id);
      
        $jobSeeker = $this->getDoctrine()
            ->getRepository('AppBundle:JobSeeker')
            ->find($id);

        if (!$jobSeeker) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return $this->render('jobseeker/view.html.twig', array('jobSeeker'=> $jobSeeker));  

    }

    /**
     * @Route("/jobseeker/view", name="jobSeeker_viewAll")
     */
    public function viewallAction( Request $request)
    {
        $createdDates = array();
        $lastDates = array();
        $repository = $this->getDoctrine()
            ->getRepository('AppBundle:JobSeeker');
        $jobSeekers = $repository->findAll();

        return $this->render('jobseeker/viewall.html.twig', array('jobSeekers' => $jobSeekers));
    }
    
    /**
     * @Route("/jobseeker/update/{id}", name="jobSeeker_update")
     */
    public function updateAction( $id,Request $request)
    {
        $fields = $this->getDoctrine()
            ->getRepository('AppBundle:Field')
            ->findAll();

        $fieldIds = array();

        foreach ($fields as $field) {
            $fieldIds[$field->getName()] = $field;
        }

        $em = $this->getDoctrine()->getManager();
        $jobSeeker = $em->getRepository('AppBundle:JobSeeker')->find($id);

        $form = $this->createFormBuilder($jobSeeker)
            ->add('name', TextType::class)
            ->add('expectedSalary', IntegerType::class)
            ->add('emailAddress', EmailType::class)
            ->add('linkedInURL', UrlType::class)
            ->add('jobSeekerField',ChoiceType::class, array(
                'choices'  => $fieldIds,
                'choices_as_values' => true,
                'label'=>'Preferred Field'
            ))
            ->add('save', SubmitType::class, array('label' => 'Update Account'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // ... perform some action, such as saving the task to the database
            $em->flush();

            return $this->redirectToRoute('jobSeeker_viewAll');
        }

        // replace this example code with whatever you need
        return $this->render('jobSeeker/update.html.twig', array('form' => $form->createView()));

    }

    /**
     * @Route("/jobseeker/linkedin/{id}", name="jobSeeker_linkedin")
     */
    public function linkedInAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $jobRecruiter = $em->getRepository('AppBundle:JobSeeker')->find($id);

        $url = $jobRecruiter->getLinkedInURL();

        return $this->redirect($url);
    }
 
}
