<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * Vacancy
 *
 * @ORM\Table(name="vacancy")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\VacancyRepository")
 */
class Vacancy
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="Position", type="string", length=50)
     */
    private $position;

    /**
     * @var string
     *
     * @ORM\Column(name="Place", type="string", length=50)
     */
    private $place;

    /**
     * @var float
     *
     * @ORM\Column(name="Latitude", type="float")
     */
    private $latitude;

    /**
     * @var float
     *
     * @ORM\Column(name="Longitude", type="float")
     */
    private $longitude;

    /**
     * @var int
     *
     * @ORM\Column(name="salaryGiven", type="integer")
     */
    private $salaryGiven;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="closingDate", type="date")
     */
    private $closingDate;


    public function __construct()
    {
        $this->jobSeekerVacancies = new ArrayCollection();
    }

//Recruiter that posted the vacancy

    /**
     * @ORM\ManyToOne(targetEntity="JobRecruiter", inversedBy="postedVacancies")
     * @ORM\JoinColumn(name="Recruiter_id", referencedColumnName="id")
     */
    private $postedVacancy;

    /**
     * @ORM\ManyToOne(targetEntity="Field", inversedBy="vacancyFields")
     * @ORM\JoinColumn(name="field_id", referencedColumnName="id")
     */
    private $vacancyField;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set place
     *
     * @param string $place
     *
     * @return Vacancy
     */
    public function setPlace($place)
    {
        $this->place = $place;

        return $this;
    }

    /**
     * Get place
     *
     * @return string
     */
    public function getPlace()
    {
        return $this->place;
    }

    /**
     * Set latitude
     *
     * @param float $latitude
     *
     * @return Vacancy
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return float
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param float $longitude
     *
     * @return Vacancy
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return float
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Set salaryGiven
     *
     * @param integer $salaryGiven
     *
     * @return Vacancy
     */
    public function setSalaryGiven($salaryGiven)
    {
        $this->salaryGiven = $salaryGiven;

        return $this;
    }

    /**
     * Get salaryGiven
     *
     * @return int
     */
    public function getSalaryGiven()
    {
        return $this->salaryGiven;
    }

    /**
     * Set closingDate
     *
     * @param \DateTime $closingDate
     *
     * @return Vacancy
     */
    public function setClosingDate($closingDate)
    {
        $this->closingDate = $closingDate;

        return $this;
    }

    /**
     * Get closingDate
     *
     * @return \DateTime
     */
    public function getClosingDate()
    {
        return $this->closingDate;
    }

    /**
     * Set position
     *
     * @param string $position
     *
     * @return Vacancy
     */
    public function setPosition($position)
    {
        $this->position = $position;

        return $this;
    }

    /**
     * Get position
     *
     * @return string
     */
    public function getPosition()
    {
        return $this->position;
    }

    /**
     * Add vacancyField
     *
     * @param \AppBundle\Entity\Field $vacancyField
     *
     * @return Vacancy
     */
    public function addVacancyField(\AppBundle\Entity\Field $vacancyField)
    {
        $this->vacancyFields[] = $vacancyField;

        return $this;
    }

    /**
     * Remove vacancyField
     *
     * @param \AppBundle\Entity\Field $vacancyField
     */
    public function removeVacancyField(\AppBundle\Entity\Field $vacancyField)
    {
        $this->vacancyFields->removeElement($vacancyField);
    }

    /**
     * Get vacancyFields
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getVacancyFields()
    {
        return $this->vacancyFields;
    }

    /**
     * Add jobSeekerField
     *
     * @param \AppBundle\Entity\JobSeeker $jobSeekerField
     *
     * @return Vacancy
     */
    public function addJobSeekerField(\AppBundle\Entity\JobSeeker $jobSeekerField)
    {
        $this->jobSeekerFields[] = $jobSeekerField;

        return $this;
    }

    /**
     * Remove jobSeekerField
     *
     * @param \AppBundle\Entity\JobSeeker $jobSeekerField
     */
    public function removeJobSeekerField(\AppBundle\Entity\JobSeeker $jobSeekerField)
    {
        $this->jobSeekerFields->removeElement($jobSeekerField);
    }

    /**
     * Get jobSeekerFields
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getJobSeekerFields()
    {
        return $this->jobSeekerFields;
    }

    /**
     * Set postedVacancy
     *
     * @param \AppBundle\Entity\JobRecruiter $postedVacancy
     *
     * @return Vacancy
     */
    public function setPostedVacancy(\AppBundle\Entity\JobRecruiter $postedVacancy = null)
    {
        $this->postedVacancy = $postedVacancy;

        return $this;
    }

    /**
     * Get postedVacancy
     *
     * @return \AppBundle\Entity\JobRecruiter
     */
    public function getPostedVacancy()
    {
        return $this->postedVacancy;
    }

    /**
     * Add jobSeekerVacancy
     *
     * @param \AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerVacancy
     *
     * @return Vacancy
     */
    public function addJobSeekerVacancy(\AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerVacancy)
    {
        $this->jobSeekerVacancies[] = $jobSeekerVacancy;

        return $this;
    }

    /**
     * Remove jobSeekerVacancy
     *
     * @param \AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerVacancy
     */
    public function removeJobSeekerVacancy(\AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerVacancy)
    {
        $this->jobSeekerVacancies->removeElement($jobSeekerVacancy);
    }

    /**
     * Get jobSeekerVacancies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getJobSeekerVacancies()
    {
        return $this->jobSeekerVacancies;
    }

    /**
     * Set vacancyField
     *
     * @param \AppBundle\Entity\Field $vacancyField
     *
     * @return Vacancy
     */
    public function setVacancyField(\AppBundle\Entity\Field $vacancyField = null)
    {
        $this->vacancyField = $vacancyField;

        return $this;
    }

    /**
     * Get vacancyField
     *
     * @return \AppBundle\Entity\Field
     */
    public function getVacancyField()
    {
        return $this->vacancyField;
    }
}
