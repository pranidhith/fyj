<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Security\Core\User\UserInterface;


/**
 * JobSeeker
 *
 * @ORM\Table(name="job_seeker")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\JobSeekerRepository")
 */
class JobSeeker implements UserInterface 
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=100)
     */
    private $name;

    /**
     * @var int
     *
     * @ORM\Column(name="expectedSalary", type="integer")
     */
    private $expectedSalary;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="accCreatedDate", type="date")
     */
    private $accCreatedDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="accLastAccessedDate", type="date")
     */
    private $accLastAccessedDate;

    /**
     * @var string
     *
     * @ORM\Column(name="linkedInURL", type="string", length=255)
     */
    private $linkedInURL;

    /**
     * @var string
     *
     * @ORM\Column(name="emailAddress", type="string", length=100)
     *
     */
    private $emailAddress;

    //Newly added - Getters and setter are just below
    /**
     * @ORM\Column(name="username", type="string", length=25, unique=true)
     */
    private $username;

    /**
     * @ORM\Column(name="password",type="string", length=64)
     */
    private $password;

    /**
     * @ORM\Column(name="is_active", type="string")
     */
    private $isActive;

    public function getSalt()
    {
        // you *may* need a real salt depending on your encoder
        // see section on salt below
        return null;
    }

    public function getRoles()
    {
        return array('ROLE_SEEKER');
    }

    public function eraseCredentials()
    {
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->username,
            $this->password,
            // see section on salt below
            // $this->salt,
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->username,
            $this->password,
            // see section on salt below
            // $this->salt
        ) = unserialize($serialized);
    }

    /**
     * @ORM\OneToMany(targetEntity="JobSeekerAppliedVacancy", mappedBy="jobSeekerApplied_Vacancy")
     */
    private $jobSeekerAppliedVacancies;

    /**
     * @ORM\ManyToOne(targetEntity="Field", inversedBy="jobSeekerFields")
     * @ORM\JoinColumn(name="field_id", referencedColumnName="id")
     */
    private $jobSeekerField;

    public function __construct()
    {
        $this->isActive = true;
        // may not be needed, see section on salt below
        // $this->salt = md5(uniqid(null, true))
        $this->jobSeekerAppliedVacancies = new ArrayCollection();
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }
    
    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return JobSeeker
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set expectedSalary
     *
     * @param integer $expectedSalary
     *
     * @return JobSeeker
     */
    public function setExpectedSalary($expectedSalary)
    {
        $this->expectedSalary = $expectedSalary;

        return $this;
    }

    /**
     * Get expectedSalary
     *
     * @return int
     */
    public function getExpectedSalary()
    {
        return $this->expectedSalary;
    }

    /**
     * Set accCreatedDate
     *
     * @param \DateTime $accCreatedDate
     *
     * @return JobSeeker
     */
    public function setAccCreatedDate($accCreatedDate)
    {
        $this->accCreatedDate = $accCreatedDate;

        return $this;
    }

    /**
     * Get accCreatedDate
     *
     * @return \DateTime
     */
    public function getAccCreatedDate()
    {
        return $this->accCreatedDate;
    }

    /**
     * Set accLastAccessedDate
     *
     * @param \DateTime $accLastAccessedDate
     *
     * @return JobSeeker
     */
    public function setAccLastAccessedDate($accLastAccessedDate)
    {
        $this->accLastAccessedDate = $accLastAccessedDate;

        return $this;
    }

    /**
     * Get accLastAccessedDate
     *
     * @return \DateTime
     */
    public function getAccLastAccessedDate()
    {
        return $this->accLastAccessedDate;
    }

    /**
     * Set linkedInURL
     *
     * @param string $linkedInURL
     *
     * @return JobSeeker
     */
    public function setLinkedInURL($linkedInURL)
    {
        $this->linkedInURL = $linkedInURL;

        return $this;
    }

    /**
     * Get linkedInURL
     *
     * @return string
     */
    public function getLinkedInURL()
    {
        return $this->linkedInURL;
    }

    /**
     * Set emailAddress
     *
     * @param string $emailAddress
     *
     * @return JobSeeker
     */
    public function setEmailAddress($emailAddress)
    {
        $this->emailAddress = $emailAddress;

        return $this;
    }

    /**
     * Get emailAddress
     *
     * @return string
     */
    public function getEmailAddress()
    {
        return $this->emailAddress;
    }

    /**
     * Set password
     *
     * @param string $password
     *
     * @return JobSeeker
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set isActive
     *
     * @param string $isActive
     *
     * @return JobSeeker
     */
    public function setIsActive($isActive)
    {
        $this->isActive = $isActive;

        return $this;
    }

    /**
     * Get isActive
     *
     * @return string
     */
    public function getIsActive()
    {
        return $this->isActive;
    }


    /**
     * Add jobSeekerAppliedVacancy
     *
     * @param \AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerAppliedVacancy
     *
     * @return JobSeeker
     */
    public function addJobSeekerAppliedVacancy(\AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerAppliedVacancy)
    {
        $this->jobSeekerAppliedVacancies[] = $jobSeekerAppliedVacancy;

        return $this;
    }

    /**
     * Remove jobSeekerAppliedVacancy
     *
     * @param \AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerAppliedVacancy
     */
    public function removeJobSeekerAppliedVacancy(\AppBundle\Entity\JobSeekerAppliedVacancy $jobSeekerAppliedVacancy)
    {
        $this->jobSeekerAppliedVacancies->removeElement($jobSeekerAppliedVacancy);
    }

    /**
     * Get jobSeekerAppliedVacancies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getJobSeekerAppliedVacancies()
    {
        return $this->jobSeekerAppliedVacancies;
    }


    /**
     * Add jobSeekerField
     *
     * @param \AppBundle\Entity\Field $jobSeekerField
     *
     * @return JobSeeker
     */
    public function addJobSeekerField(\AppBundle\Entity\Field $jobSeekerField)
    {
        $this->jobSeekerFields[] = $jobSeekerField;

        return $this;
    }

    /**
     * Remove jobSeekerField
     *
     * @param \AppBundle\Entity\Field $jobSeekerField
     */
    public function removeJobSeekerField(\AppBundle\Entity\Field $jobSeekerField)
    {
        $this->jobSeekerFields->removeElement($jobSeekerField);
    }

    /**
     * Get jobSeekerFields
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getJobSeekerFields()
    {
        return $this->jobSeekerFields;
    }

    /**
     * Set jobSeekerField
     *
     * @param \AppBundle\Entity\Field $jobSeekerField
     *
     * @return JobSeeker
     */
    public function setJobSeekerField(\AppBundle\Entity\Field $jobSeekerField = null)
    {
        $this->jobSeekerField = $jobSeekerField;

        return $this;
    }

    /**
     * Get jobSeekerField
     *
     * @return \AppBundle\Entity\Field
     */
    public function getJobSeekerField()
    {
        return $this->jobSeekerField;
    }
}
