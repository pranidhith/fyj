<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * JobSeekerAppliedVacancy
 *
 * @ORM\Table(name="job_seeker_applied_vacancy")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\JobSeekerAppliedVacancyRepository")
 */
class JobSeekerAppliedVacancy
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @Assert\File(maxSize="6000000")
     */
    private $cV;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255)
     */
    private $description;

    /**
     * @ORM\ManyToOne(targetEntity="JobSeeker", inversedBy="jobSeekerAppliedVacancies")
     * @ORM\JoinColumn(name="JobSeeker_id", referencedColumnName="id")
     */
    private $jobSeekerAppliedVacancy;

    /**
     * @ORM\ManyToOne(targetEntity="Vacancy", inversedBy="jobSeekerVacancies")
     * @ORM\JoinColumn(name="Vacancy_id", referencedColumnName="id")
     */
    private $jobSeekerVacancy;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    public $path;

    public function getAbsolutePath()
    {
        return null === $this->path
            ? null
            : $this->getUploadRootDir().'/'.$this->path;
    }

    public function getWebPath()
    {
        return null === $this->path
            ? null
            : $this->getUploadDir().'/'.$this->path;
    }

    protected function getUploadRootDir()
    {
        // the absolute directory path where uploaded
        // documents should be saved
        return __DIR__.'/../../../../web/'.$this->getUploadDir();
    }

    protected function getUploadDir()
    {
        // get rid of the __DIR__ so it doesn't screw up
        // when displaying uploaded doc/image in the view.
        return 'uploads/documents';
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Sets cV.
     *
     * @param UploadedFile $cV
     */
    public function setcV(UploadedFile $cV = null)
    {
        $this->cV = $cV;
    }

    /**
     * Get cV.
     *
     * @return UploadedFile
     */
    public function getcV()
    {
        return $this->cV;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return JobSeekerAppliedVacancy
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set jobSeekerAppliedVacancy
     *
     * @param \AppBundle\Entity\JobSeeker $jobSeekerAppliedVacancy
     *
     * @return JobSeekerAppliedVacancy
     */
    public function setJobSeekerAppliedVacancy(\AppBundle\Entity\JobSeeker $jobSeekerAppliedVacancy = null)
    {
        $this->jobSeekerAppliedVacancy = $jobSeekerAppliedVacancy;

        return $this;
    }

    /**
     * Get jobSeekerAppliedVacancy
     *
     * @return \AppBundle\Entity\JobSeeker
     */
    public function getJobSeekerAppliedVacancy()
    {
        return $this->jobSeekerAppliedVacancy;
    }

    /**
     * Set jobSeekerVacancy
     *
     * @param \AppBundle\Entity\Vacancy $jobSeekerVacancy
     *
     * @return JobSeekerAppliedVacancy
     */
    public function setJobSeekerVacancy(\AppBundle\Entity\Vacancy $jobSeekerVacancy = null)
    {
        $this->jobSeekerVacancy = $jobSeekerVacancy;

        return $this;
    }

    /**
     * Get jobSeekerVacancy
     *
     * @return \AppBundle\Entity\Vacancy
     */
    public function getJobSeekerVacancy()
    {
        return $this->jobSeekerVacancy;
    }

    public function upload()
    {
        // the file property can be empty if the field is not required
        if (null === $this->getcV()) {
            return;
        }

        // use the original file name here but you should
        // sanitize it at least to avoid any security issues

        // move takes the target directory and then the
        // target filename to move to
        $this->getcV()->move(
            $this->getUploadRootDir(),
            $this->getcV()->getClientOriginalName()
        );

        // set the path property to the filename where you've saved the file
        $this->path = $this->getcV()->getClientOriginalName();

        // clean up the file property as you won't need it anymore
        $this->file = null;
    }

    /**
     * Set path
     *
     * @param string $path
     *
     * @return JobSeekerAppliedVacancy
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * Get path
     *
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * @ORM\PostRemove()
     */
    public function removeUpload()
    {
        if ($file = $this->getAbsolutePath()) {
            unlink($file);
        }
    }
}
