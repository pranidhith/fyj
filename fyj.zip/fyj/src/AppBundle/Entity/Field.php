<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Field
 *
 * @ORM\Table(name="field")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\FieldRepository")
 */
class Field
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255)
     */
    private $description;

    /**
     * @ORM\OneToMany(targetEntity="Vacancy", mappedBy="vacancyField")
     */
    private $vacancyFields;

    /**
     * @ORM\OneToMany(targetEntity="JobSeeker", mappedBy="jobSeekerField")
     */
    private $jobSeekerFields;


    public function __construct()
    {
        $this->vacancyFields= new ArrayCollection();
        $this->jobSeekerFields = new ArrayCollection();
        $this->fieldJobSeekers = new ArrayCollection();
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Field
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Field
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }



    /**
     * Set vacancyField
     *
     * @param \AppBundle\Entity\Vacancy $vacancyField
     *
     * @return Field
     */
    public function setVacancyField(\AppBundle\Entity\Vacancy $vacancyField = null)
    {
        $this->vacancyField = $vacancyField;

        return $this;
    }

    /**
     * Get vacancyField
     *
     * @return \AppBundle\Entity\Vacancy
     */
    public function getVacancyField()
    {
        return $this->vacancyField;
    }


    /**
     * Set jobSeekerField
     *
     * @param \AppBundle\Entity\Vacancy $jobSeekerField
     *
     * @return Field
     */
    public function setJobSeekerField(\AppBundle\Entity\Vacancy $jobSeekerField = null)
    {
        $this->jobSeekerField = $jobSeekerField;

        return $this;
    }

    /**
     * Get jobSeekerField
     *
     * @return \AppBundle\Entity\Vacancy
     */
    public function getJobSeekerField()
    {
        return $this->jobSeekerField;
    }

    /**
     * Add vacancyField
     *
     * @param \AppBundle\Entity\Vacancy $vacancyField
     *
     * @return Field
     */
    public function addVacancyField(\AppBundle\Entity\Vacancy $vacancyField)
    {
        $this->vacancyFields[] = $vacancyField;

        return $this;
    }

    /**
     * Remove vacancyField
     *
     * @param \AppBundle\Entity\Vacancy $vacancyField
     */
    public function removeVacancyField(\AppBundle\Entity\Vacancy $vacancyField)
    {
        $this->vacancyFields->removeElement($vacancyField);
    }

    /**
     * Get vacancyFields
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getVacancyFields()
    {
        return $this->vacancyFields;
    }

    /**
     * Add jobSeekerField
     *
     * @param \AppBundle\Entity\JobSeeker $jobSeekerField
     *
     * @return Field
     */
    public function addJobSeekerField(\AppBundle\Entity\JobSeeker $jobSeekerField)
    {
        $this->jobSeekerFields[] = $jobSeekerField;

        return $this;
    }

    /**
     * Remove jobSeekerField
     *
     * @param \AppBundle\Entity\JobSeeker $jobSeekerField
     */
    public function removeJobSeekerField(\AppBundle\Entity\JobSeeker $jobSeekerField)
    {
        $this->jobSeekerFields->removeElement($jobSeekerField);
    }

    /**
     * Get jobSeekerFields
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getJobSeekerFields()
    {
        return $this->jobSeekerFields;
    }
}
