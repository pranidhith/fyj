<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Security\Core\User\UserInterface;


/**
 * JobRecruiter
 *
 * @ORM\Table(name="job_recruiter")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\JobRecruiterRepository")
 */
class JobRecruiter implements UserInterface 
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=100)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="companyName", type="string", length=50)
     */
    private $companyName;

    /**
     * @var string
     *
     * @ORM\Column(name="companyAddress", type="string", length=100)
     */
    private $companyAddress;

    /**
     * @var float
     *
     * @ORM\Column(name="latitude", type="float")
     */
    private $latitude;

    /**
     * @var string
     *
     * @ORM\Column(name="longitude", type="float")
     */
    private $longitude;

    /**
     * @var string
     *
     * @ORM\Column(name="emailAddress", type="string", length=100)
     *
     *
     */
    private $emailAddress;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="accCreatedDate", type="date")
     */
    private $accCreatedDate;

    /**
     * @var string
     *
     * @ORM\Column(name="accLastAccessedDate", type="date")
     */
    private $accLastAccessedDate;

    /**
     * @var string
     *
     * @ORM\Column(name="linkedInURL", type="string", length=255)
     */
    private $linkedInURL;

    /**
     * @ORM\OneToMany(targetEntity="Vacancy", mappedBy="postedVacancy")
     */
    private $postedVacancies;

    /**
     * @ORM\OneToMany(targetEntity="Advertisement", mappedBy="submittedAd")
     */
    private $submittedAds;

    //Newly added - Getters and setter are just below
    /**
     * @ORM\Column(name="username", type="string", length=25, unique=true)
     */
    private $username;

    /**
     * @ORM\Column(name="password",type="string", length=64)
     */
    private $password;

    /**
     * @ORM\Column(name="is_active", type="string")
     */
    private $isActive;

    public function getSalt()
    {
        // you *may* need a real salt depending on your encoder
        // see section on salt below
        return null;
    }

    public function getRoles()
    {
        return array('ROLE_RECRUITER');
    }

    public function eraseCredentials()
    {
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->username,
            $this->password,
            // see section on salt below
            // $this->salt,
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->username,
            $this->password,
            // see section on salt below
            // $this->salt
        ) = unserialize($serialized);
    }
    


    public function __construct()
    {
        $this->isActive = true;
        $this->postedVacancies = new ArrayCollection();
        $this->submittedAds = new ArrayCollection();
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }
    
    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * Set password
     *
     * @param string $password
     *
     * @return JobSeeker
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }



    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return JobRecruiter
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set companyName
     *
     * @param string $companyName
     *
     * @return JobRecruiter
     */
    public function setCompanyName($companyName)
    {
        $this->companyName = $companyName;

        return $this;
    }

    /**
     * Get companyName
     *
     * @return string
     */
    public function getCompanyName()
    {
        return $this->companyName;
    }

    /**
     * Set companyAddress
     *
     * @param string $companyAddress
     *
     * @return JobRecruiter
     */
    public function setCompanyAddress($companyAddress)
    {
        $this->companyAddress = $companyAddress;

        return $this;
    }

    /**
     * Get companyAddress
     *
     * @return string
     */
    public function getCompanyAddress()
    {
        return $this->companyAddress;
    }

    /**
     * Set latitude
     *
     * @param float $latitude
     *
     * @return JobRecruiter
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return float
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     *
     * @return JobRecruiter
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return string
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Set emailAddress
     *
     * @param string $emailAddress
     *
     * @return JobRecruiter
     */
    public function setEmailAddress($emailAddress)
    {
        $this->emailAddress = $emailAddress;

        return $this;
    }

    /**
     * Get emailAddress
     *
     * @return string
     */
    public function getEmailAddress()
    {
        return $this->emailAddress;
    }

    /**
     * Set accCreatedDate
     *
     * @param \DateTime $accCreatedDate
     *
     * @return JobRecruiter
     */
    public function setAccCreatedDate($accCreatedDate)
    {
        $this->accCreatedDate = $accCreatedDate;

        return $this;
    }

    /**
     * Get accCreatedDate
     *
     * @return \DateTime
     */
    public function getAccCreatedDate()
    {
        return $this->accCreatedDate;
    }

    /**
     * Set accLastAccessedDate
     *
     * @param string $accLastAccessedDate
     *
     * @return JobRecruiter
     */
    public function setAccLastAccessedDate($accLastAccessedDate)
    {
        $this->accLastAccessedDate = $accLastAccessedDate;

        return $this;
    }

    /**
     * Get accLastAccessedDate
     *
     * @return string
     */
    public function getAccLastAccessedDate()
    {
        return $this->accLastAccessedDate;
    }

    /**
     * Set linkedInURL
     *
     * @param string $linkedInURL
     *
     * @return JobRecruiter
     */
    public function setLinkedInURL($linkedInURL)
    {
        $this->linkedInURL = $linkedInURL;

        return $this;
    }

    /**
     * Get linkedInURL
     *
     * @return string
     */
    public function getLinkedInURL()
    {
        return $this->linkedInURL;
    }

    /**
     * Add postedVacancy
     *
     * @param \AppBundle\Entity\Vacancy $postedVacancy
     *
     * @return JobRecruiter
     */
    public function addPostedVacancy(\AppBundle\Entity\Vacancy $postedVacancy)
    {
        $this->postedVacancies[] = $postedVacancy;

        return $this;
    }

    /**
     * Remove postedVacancy
     *
     * @param \AppBundle\Entity\Vacancy $postedVacancy
     */
    public function removePostedVacancy(\AppBundle\Entity\Vacancy $postedVacancy)
    {
        $this->postedVacancies->removeElement($postedVacancy);
    }

    /**
     * Get postedVacancies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPostedVacancies()
    {
        return $this->postedVacancies;
    }

    /**
     * Add submittedAd
     *
     * @param \AppBundle\Entity\Advertisement $submittedAd
     *
     * @return JobRecruiter
     */
    public function addSubmittedAd(\AppBundle\Entity\Advertisement $submittedAd)
    {
        $this->submittedAds[] = $submittedAd;

        return $this;
    }

    /**
     * Remove submittedAd
     *
     * @param \AppBundle\Entity\Advertisement $submittedAd
     */
    public function removeSubmittedAd(\AppBundle\Entity\Advertisement $submittedAd)
    {
        $this->submittedAds->removeElement($submittedAd);
    }

    /**
     * Get submittedAds
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getSubmittedAds()
    {
        return $this->submittedAds;
    }

    /**
     * Set isActive
     *
     * @param string $isActive
     *
     * @return JobRecruiter
     */
    public function setIsActive($isActive)
    {
        $this->isActive = $isActive;

        return $this;
    }

    /**
     * Get isActive
     *
     * @return string
     */
    public function getIsActive()
    {
        return $this->isActive;
    }
}
