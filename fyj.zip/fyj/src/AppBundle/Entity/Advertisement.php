<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Advertisement
 *
 * @ORM\Table(name="advertisement")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\AdvertisementRepository")
 */
class Advertisement
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="sizeX", type="integer")
     */
    private $sizeX;

    /**
     * @var int
     *
     * @ORM\Column(name="sizeY", type="integer")
     */
    private $sizeY;

    /**
     * @var int
     *
     * @ORM\Column(name="daysToDisplay", type="integer")
     */
    private $daysToDisplay;

    /**
     * @Assert\File(maxSize="6000000")
     */
    private $image;

    /**
     * @ORM\ManyToOne(targetEntity="JobRecruiter", inversedBy="submittedAds")
     * @ORM\JoinColumn(name="Recruiter_id", referencedColumnName="id")
     */
    private $submittedAd;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    public $path;

    public function getAbsolutePath()
    {
        return null === $this->path
            ? null
            : $this->getUploadRootDir().'/'.$this->path;
    }

    public function getWebPath()
    {
        return null === $this->path
            ? null
            : $this->getUploadDir().'/'.$this->path;
    }

    protected function getUploadRootDir()
    {
        // the absolute directory path where uploaded
        // documents should be saved
        return __DIR__.'/../../../../web/'.$this->getUploadDir();
    }

    protected function getUploadDir()
    {
        // get rid of the __DIR__ so it doesn't screw up
        // when displaying uploaded doc/image in the view.
        return 'uploads/documents';
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sizeX
     *
     * @param integer $sizeX
     *
     * @return Advertisement
     */
    public function setSizeX($sizeX)
    {
        $this->sizeX = $sizeX;

        return $this;
    }

    /**
     * Get sizeX
     *
     * @return int
     */
    public function getSizeX()
    {
        return $this->sizeX;
    }

    /**
     * Set sizeY
     *
     * @param integer $sizeY
     *
     * @return Advertisement
     */
    public function setSizeY($sizeY)
    {
        $this->sizeY = $sizeY;

        return $this;
    }

    /**
     * Get sizeY
     *
     * @return int
     */
    public function getSizeY()
    {
        return $this->sizeY;
    }

    /**
     * Set daysToDisplay
     *
     * @param integer $daysToDisplay
     *
     * @return Advertisement
     */
    public function setDaysToDisplay($daysToDisplay)
    {
        $this->daysToDisplay = $daysToDisplay;

        return $this;
    }

    /**
     * Get daysToDisplay
     *
     * @return int
     */
    public function getDaysToDisplay()
    {
        return $this->daysToDisplay;
    }

    /**
     * Set image
     *
     * @param string $image
     *
     * @return Advertisement
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set submittedAd
     *
     * @param \AppBundle\Entity\JobRecruiter $submittedAd
     *
     * @return Advertisement
     */
    public function setSubmittedAd(\AppBundle\Entity\JobRecruiter $submittedAd = null)
    {
        $this->submittedAd = $submittedAd;

        return $this;
    }

    /**
     * Get submittedAd
     *
     * @return \AppBundle\Entity\JobRecruiter
     */
    public function getSubmittedAd()
    {
        return $this->submittedAd;
    }

    public function upload()
    {
        // the file property can be empty if the field is not required
        if (null === $this->getImage()) {
            return;
        }

        // use the original file name here but you should
        // sanitize it at least to avoid any security issues

        // move takes the target directory and then the
        // target filename to move to
        $this->getImage()->move(
            $this->getUploadRootDir(),
            $this->getImage()->getClientOriginalName()
        );

        // set the path property to the filename where you've saved the file
        $this->path = $this->getImage()->getClientOriginalName();

        // clean up the file property as you won't need it anymore
        $this->file = null;
    }

    /**
     * Set path
     *
     * @param string $path
     *
     * @return Advertisement
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * Get path
     *
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * @ORM\PostRemove()
     */
    public function removeUpload()
    {
        if ($file = $this->getAbsolutePath()) {
            unlink($file);
        }
    }

}
