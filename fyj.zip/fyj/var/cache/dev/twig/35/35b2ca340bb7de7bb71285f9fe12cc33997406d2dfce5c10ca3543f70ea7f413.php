<?php

/* apply/view.html.twig */
class __TwigTemplate_dfdc085d1d7821dea9972ec38bc43ffcdbfaff58ab2d4f60a5881abedfd7f45c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "apply/view.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d50f7ec56ba40b0bba2da149e9752089ddc4b484ae858ca1f7f7c97875e6965 = $this->env->getExtension("native_profiler");
        $__internal_7d50f7ec56ba40b0bba2da149e9752089ddc4b484ae858ca1f7f7c97875e6965->enter($__internal_7d50f7ec56ba40b0bba2da149e9752089ddc4b484ae858ca1f7f7c97875e6965_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "apply/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7d50f7ec56ba40b0bba2da149e9752089ddc4b484ae858ca1f7f7c97875e6965->leave($__internal_7d50f7ec56ba40b0bba2da149e9752089ddc4b484ae858ca1f7f7c97875e6965_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_2a9be99134e46de17cb50fa4a6ec6fb1eaa7c63234b3cadce82364261d876a0f = $this->env->getExtension("native_profiler");
        $__internal_2a9be99134e46de17cb50fa4a6ec6fb1eaa7c63234b3cadce82364261d876a0f->enter($__internal_2a9be99134e46de17cb50fa4a6ec6fb1eaa7c63234b3cadce82364261d876a0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "Applied Vacancy Details
";
        
        $__internal_2a9be99134e46de17cb50fa4a6ec6fb1eaa7c63234b3cadce82364261d876a0f->leave($__internal_2a9be99134e46de17cb50fa4a6ec6fb1eaa7c63234b3cadce82364261d876a0f_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_480acfef14049a0805c7d73b2bbf5adb94b2f10cbeccedbbfb8b570ff3f28479 = $this->env->getExtension("native_profiler");
        $__internal_480acfef14049a0805c7d73b2bbf5adb94b2f10cbeccedbbfb8b570ff3f28479->enter($__internal_480acfef14049a0805c7d73b2bbf5adb94b2f10cbeccedbbfb8b570ff3f28479_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
<table style=\"width:50%\">
  <tr>
    <td><b>Description:</b></td>
    <td>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["appliedvacancy"]) ? $context["appliedvacancy"] : $this->getContext($context, "appliedvacancy")), "description", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Seeker:</b></td>
    <td>";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["appliedvacancy"]) ? $context["appliedvacancy"] : $this->getContext($context, "appliedvacancy")), "getJobSeekerAppliedVacancy", array(), "method"), "getName", array(), "method"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Vacancy Position:</b></td>
    <td>";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["appliedvacancy"]) ? $context["appliedvacancy"] : $this->getContext($context, "appliedvacancy")), "getJobSeekerVacancy", array(), "method"), "getPosition", array(), "method"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Vacancy Company:</b></td>
    <td>";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["appliedvacancy"]) ? $context["appliedvacancy"] : $this->getContext($context, "appliedvacancy")), "getJobSeekerVacancy", array(), "method"), "getPostedVacancy", array(), "method"), "getCompanyName", array(), "method"), "html", null, true);
        echo "</td>
  </tr>
</table>

";
        
        $__internal_480acfef14049a0805c7d73b2bbf5adb94b2f10cbeccedbbfb8b570ff3f28479->leave($__internal_480acfef14049a0805c7d73b2bbf5adb94b2f10cbeccedbbfb8b570ff3f28479_prof);

    }

    public function getTemplateName()
    {
        return "apply/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 27,  75 => 23,  68 => 19,  61 => 15,  55 => 11,  49 => 10,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* */
/* {# app/Resources/views/jobseeker/view.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Applied Vacancy Details*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* <table style="width:50%">*/
/*   <tr>*/
/*     <td><b>Description:</b></td>*/
/*     <td>{{appliedvacancy.description}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Seeker:</b></td>*/
/*     <td>{{appliedvacancy.getJobSeekerAppliedVacancy().getName()}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Vacancy Position:</b></td>*/
/*     <td>{{appliedvacancy.getJobSeekerVacancy().getPosition()}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Vacancy Company:</b></td>*/
/*     <td>{{appliedvacancy.getJobSeekerVacancy().getPostedVacancy().getCompanyName()}}</td>*/
/*   </tr>*/
/* </table>*/
/* */
/* {% endblock %}*/
/* */
