<?php

/* vacancy/create.html.twig */
class __TwigTemplate_8ce5f135d94bd62e7b2d2987af184d06bda55a4c259abe9d79bb571acd93846c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "vacancy/create.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bed1885d772dff233381d0cdc6c424f5857d8872bbef10ecddd313533fe368d8 = $this->env->getExtension("native_profiler");
        $__internal_bed1885d772dff233381d0cdc6c424f5857d8872bbef10ecddd313533fe368d8->enter($__internal_bed1885d772dff233381d0cdc6c424f5857d8872bbef10ecddd313533fe368d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vacancy/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bed1885d772dff233381d0cdc6c424f5857d8872bbef10ecddd313533fe368d8->leave($__internal_bed1885d772dff233381d0cdc6c424f5857d8872bbef10ecddd313533fe368d8_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_ba1ae1e50e3c3656c2383adf6cd3446422285ccc1b01c3683f8e4f8a40b86752 = $this->env->getExtension("native_profiler");
        $__internal_ba1ae1e50e3c3656c2383adf6cd3446422285ccc1b01c3683f8e4f8a40b86752->enter($__internal_ba1ae1e50e3c3656c2383adf6cd3446422285ccc1b01c3683f8e4f8a40b86752_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Create Vacancy
";
        
        $__internal_ba1ae1e50e3c3656c2383adf6cd3446422285ccc1b01c3683f8e4f8a40b86752->leave($__internal_ba1ae1e50e3c3656c2383adf6cd3446422285ccc1b01c3683f8e4f8a40b86752_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_0cfc17fe25d34478cff0e8176237d13a23fa9ee7f8a52c23baef290f98677713 = $this->env->getExtension("native_profiler");
        $__internal_0cfc17fe25d34478cff0e8176237d13a23fa9ee7f8a52c23baef290f98677713->enter($__internal_0cfc17fe25d34478cff0e8176237d13a23fa9ee7f8a52c23baef290f98677713_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "    
";
        
        $__internal_0cfc17fe25d34478cff0e8176237d13a23fa9ee7f8a52c23baef290f98677713->leave($__internal_0cfc17fe25d34478cff0e8176237d13a23fa9ee7f8a52c23baef290f98677713_prof);

    }

    public function getTemplateName()
    {
        return "vacancy/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 11,  59 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Create Vacancy*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}    */
/* {% endblock %}*/
