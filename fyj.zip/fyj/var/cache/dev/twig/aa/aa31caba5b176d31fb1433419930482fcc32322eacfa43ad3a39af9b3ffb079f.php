<?php

/* apply/viewall.html.twig */
class __TwigTemplate_1e4ea7a9ac520a4463426a35e4ef479bb6d5b0ba4fc0fdc4bd482b263d065aba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "apply/viewall.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b94dc4aa27cdafd5bb720e62ce71bd64137921fe7d8e132cf02ad28d708c15a9 = $this->env->getExtension("native_profiler");
        $__internal_b94dc4aa27cdafd5bb720e62ce71bd64137921fe7d8e132cf02ad28d708c15a9->enter($__internal_b94dc4aa27cdafd5bb720e62ce71bd64137921fe7d8e132cf02ad28d708c15a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "apply/viewall.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b94dc4aa27cdafd5bb720e62ce71bd64137921fe7d8e132cf02ad28d708c15a9->leave($__internal_b94dc4aa27cdafd5bb720e62ce71bd64137921fe7d8e132cf02ad28d708c15a9_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_8f77809bbe6adf7244034daf2a2698f1793a225054b9dbbf9d2751c887109271 = $this->env->getExtension("native_profiler");
        $__internal_8f77809bbe6adf7244034daf2a2698f1793a225054b9dbbf9d2751c887109271->enter($__internal_8f77809bbe6adf7244034daf2a2698f1793a225054b9dbbf9d2751c887109271_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "    All Job Seekers
";
        
        $__internal_8f77809bbe6adf7244034daf2a2698f1793a225054b9dbbf9d2751c887109271->leave($__internal_8f77809bbe6adf7244034daf2a2698f1793a225054b9dbbf9d2751c887109271_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_3bcd621430950583376fe572985cb3f52e2bf3e3c8ea4a0f1787786f0577d8e6 = $this->env->getExtension("native_profiler");
        $__internal_3bcd621430950583376fe572985cb3f52e2bf3e3c8ea4a0f1787786f0577d8e6->enter($__internal_3bcd621430950583376fe572985cb3f52e2bf3e3c8ea4a0f1787786f0577d8e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    <table width=\"100%\">
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>CV</th>
        </tr>

        ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["appliedvacancies"]) ? $context["appliedvacancies"] : $this->getContext($context, "appliedvacancies")));
        foreach ($context['_seq'] as $context["_key"] => $context["av"]) {
            // line 19
            echo "            <tr>
                <td>
                    <a href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobSeeker_view", array("id" => $this->getAttribute($this->getAttribute($context["av"], "getJobSeekerAppliedVacancy", array(), "method"), "getId", array(), "method"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["av"], "getJobSeekerAppliedVacancy", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "</a>
                </td>

                <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["av"], "Description", array()));
            echo "
                </td>

                ";
            // line 29
            echo "
                <td>
                    <div class=\"btn-group\" >

                        <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("event_file", array("id" => $this->getAttribute($context["av"], "id", array()))), "html", null, true);
            echo "\"><button type=\"button\" class=\"btn btn-xs btn-warning\">View CV</button></a>

                    </div>
                </td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['av'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "

    </table>

";
        
        $__internal_3bcd621430950583376fe572985cb3f52e2bf3e3c8ea4a0f1787786f0577d8e6->leave($__internal_3bcd621430950583376fe572985cb3f52e2bf3e3c8ea4a0f1787786f0577d8e6_prof);

    }

    public function getTemplateName()
    {
        return "apply/viewall.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 40,  93 => 33,  87 => 29,  81 => 24,  73 => 21,  69 => 19,  65 => 18,  55 => 10,  49 => 9,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     All Job Seekers*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/*     <table width="100%">*/
/*         <tr>*/
/*             <th>Name</th>*/
/*             <th>Description</th>*/
/*             <th>CV</th>*/
/*         </tr>*/
/* */
/*         {% for av in appliedvacancies %}*/
/*             <tr>*/
/*                 <td>*/
/*                     <a href="{{url('jobSeeker_view',{'id':av.getJobSeekerAppliedVacancy().getId()})}}">{{ av.getJobSeekerAppliedVacancy().getName() }}</a>*/
/*                 </td>*/
/* */
/*                 <td>{{ av.Description|e }}*/
/*                 </td>*/
/* */
/*                 {#<td>{{ av.getAbsolutePath() }}*/
/*                 </td>#}*/
/* */
/*                 <td>*/
/*                     <div class="btn-group" >*/
/* */
/*                         <a href="{{ url('event_file', {'id':av.id}) }}"><button type="button" class="btn btn-xs btn-warning">View CV</button></a>*/
/* */
/*                     </div>*/
/*                 </td>*/
/* */
/*             </tr>*/
/*         {% endfor %}*/
/* */
/* */
/*     </table>*/
/* */
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
