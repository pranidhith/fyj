<?php

/* advertisement/viewall.html.twig */
class __TwigTemplate_f9aac9ff19df4f1dbcba42b303f7538157782abf7a0138556bbf8a46b17f1e96 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "advertisement/viewall.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_736894dde66054ca8e5f6a8027986ebade4d9b982368a9a3edf34223894646c0 = $this->env->getExtension("native_profiler");
        $__internal_736894dde66054ca8e5f6a8027986ebade4d9b982368a9a3edf34223894646c0->enter($__internal_736894dde66054ca8e5f6a8027986ebade4d9b982368a9a3edf34223894646c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "advertisement/viewall.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_736894dde66054ca8e5f6a8027986ebade4d9b982368a9a3edf34223894646c0->leave($__internal_736894dde66054ca8e5f6a8027986ebade4d9b982368a9a3edf34223894646c0_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_9c16d9c4518152653f46b4e6f72651394980c40672c4350ecccc713227e2ee09 = $this->env->getExtension("native_profiler");
        $__internal_9c16d9c4518152653f46b4e6f72651394980c40672c4350ecccc713227e2ee09->enter($__internal_9c16d9c4518152653f46b4e6f72651394980c40672c4350ecccc713227e2ee09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "    All Advertisements
";
        
        $__internal_9c16d9c4518152653f46b4e6f72651394980c40672c4350ecccc713227e2ee09->leave($__internal_9c16d9c4518152653f46b4e6f72651394980c40672c4350ecccc713227e2ee09_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_f22845dfbda6d7f0d85eaca037a50ccc70c6e14e3d6b9e9e0dea8e8dd9d72713 = $this->env->getExtension("native_profiler");
        $__internal_f22845dfbda6d7f0d85eaca037a50ccc70c6e14e3d6b9e9e0dea8e8dd9d72713->enter($__internal_f22845dfbda6d7f0d85eaca037a50ccc70c6e14e3d6b9e9e0dea8e8dd9d72713_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    <table width=\"100%\">
        <tr>
            <th>Advertisement ID</th>
            <th>Size X</th>
            <th>Size Y</th>
            <th>Days to Display</th>
            <th>Company Name</th>
            <th>Image</th>
        </tr>

        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["advertisements"]) ? $context["advertisements"] : $this->getContext($context, "advertisements")));
        foreach ($context['_seq'] as $context["_key"] => $context["ad"]) {
            // line 22
            echo "            <tr>
                <td>
                    <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("advertisement_view", array("id" => $this->getAttribute($context["ad"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ad"], "id", array()), "html", null, true);
            echo "</a>
                </td>

                <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["ad"], "sizeX", array()));
            echo "
                </td>

                <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["ad"], "sizeY", array()));
            echo "
                </td>

                <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["ad"], "daysToDisplay", array()));
            echo "
                </td>

                <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["ad"], "getSubmittedAd", array(), "method"), "getCompanyName", array(), "method"), "html", null, true);
            echo "
                </td>

                <td>
                    <div class=\"btn-group\" >

                        <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("advertisement_file", array("id" => $this->getAttribute($context["ad"], "id", array()))), "html", null, true);
            echo "\"><button type=\"button\" class=\"btn btn-xs btn-warning\">View Image</button></a>

                    </div>
                </td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ad'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "

    </table>

";
        
        $__internal_f22845dfbda6d7f0d85eaca037a50ccc70c6e14e3d6b9e9e0dea8e8dd9d72713->leave($__internal_f22845dfbda6d7f0d85eaca037a50ccc70c6e14e3d6b9e9e0dea8e8dd9d72713_prof);

    }

    public function getTemplateName()
    {
        return "advertisement/viewall.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 49,  111 => 42,  102 => 36,  96 => 33,  90 => 30,  84 => 27,  76 => 24,  72 => 22,  68 => 21,  55 => 10,  49 => 9,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     All Advertisements*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/*     <table width="100%">*/
/*         <tr>*/
/*             <th>Advertisement ID</th>*/
/*             <th>Size X</th>*/
/*             <th>Size Y</th>*/
/*             <th>Days to Display</th>*/
/*             <th>Company Name</th>*/
/*             <th>Image</th>*/
/*         </tr>*/
/* */
/*         {% for ad in advertisements %}*/
/*             <tr>*/
/*                 <td>*/
/*                     <a href="{{url('advertisement_view',{'id':ad.id})}}">{{ ad.id }}</a>*/
/*                 </td>*/
/* */
/*                 <td>{{ ad.sizeX|e }}*/
/*                 </td>*/
/* */
/*                 <td>{{ ad.sizeY|e }}*/
/*                 </td>*/
/* */
/*                 <td>{{ ad.daysToDisplay|e }}*/
/*                 </td>*/
/* */
/*                 <td>{{ad.getSubmittedAd().getCompanyName()}}*/
/*                 </td>*/
/* */
/*                 <td>*/
/*                     <div class="btn-group" >*/
/* */
/*                         <a href="{{ url('advertisement_file', {'id':ad.id}) }}"><button type="button" class="btn btn-xs btn-warning">View Image</button></a>*/
/* */
/*                     </div>*/
/*                 </td>*/
/* */
/*             </tr>*/
/*         {% endfor %}*/
/* */
/* */
/*     </table>*/
/* */
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
