<?php

/* Vacancy/update.html.twig */
class __TwigTemplate_1bba544fbf33e502bfc38c8092fc2d6ae21f6d4798aa0ce1524978537f633855 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "Vacancy/update.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_630dad8c75f0c814a60a6291b8675ae38e8c2cd12e389413b3dd0000e09d2011 = $this->env->getExtension("native_profiler");
        $__internal_630dad8c75f0c814a60a6291b8675ae38e8c2cd12e389413b3dd0000e09d2011->enter($__internal_630dad8c75f0c814a60a6291b8675ae38e8c2cd12e389413b3dd0000e09d2011_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Vacancy/update.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_630dad8c75f0c814a60a6291b8675ae38e8c2cd12e389413b3dd0000e09d2011->leave($__internal_630dad8c75f0c814a60a6291b8675ae38e8c2cd12e389413b3dd0000e09d2011_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_8788446595c5477672900b236308352a1b17696f1c265fc549079cf10e9fac90 = $this->env->getExtension("native_profiler");
        $__internal_8788446595c5477672900b236308352a1b17696f1c265fc549079cf10e9fac90->enter($__internal_8788446595c5477672900b236308352a1b17696f1c265fc549079cf10e9fac90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Update Vacancy
";
        
        $__internal_8788446595c5477672900b236308352a1b17696f1c265fc549079cf10e9fac90->leave($__internal_8788446595c5477672900b236308352a1b17696f1c265fc549079cf10e9fac90_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_39514e1bfc6d71c8abf8bc2eccf09aa2eb029aad665018d7a261532300f86a50 = $this->env->getExtension("native_profiler");
        $__internal_39514e1bfc6d71c8abf8bc2eccf09aa2eb029aad665018d7a261532300f86a50->enter($__internal_39514e1bfc6d71c8abf8bc2eccf09aa2eb029aad665018d7a261532300f86a50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "    
";
        
        $__internal_39514e1bfc6d71c8abf8bc2eccf09aa2eb029aad665018d7a261532300f86a50->leave($__internal_39514e1bfc6d71c8abf8bc2eccf09aa2eb029aad665018d7a261532300f86a50_prof);

    }

    public function getTemplateName()
    {
        return "Vacancy/update.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 11,  59 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/equipment/update.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Update Vacancy*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}    */
/* {% endblock %}*/
