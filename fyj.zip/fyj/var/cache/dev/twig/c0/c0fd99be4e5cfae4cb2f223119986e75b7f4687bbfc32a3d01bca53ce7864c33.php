<?php

/* base.html.twig */
class __TwigTemplate_2b99bfa3730b56ccdd5fb3175bb0e104bbb0209cd7c6dffcd8bdc8cc3b30ea6a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'links' => array($this, 'block_links'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f36750604337ad9b1f4a52c6da006121465e1c73d8add920c1ceb4185407e63a = $this->env->getExtension("native_profiler");
        $__internal_f36750604337ad9b1f4a52c6da006121465e1c73d8add920c1ceb4185407e63a->enter($__internal_f36750604337ad9b1f4a52c6da006121465e1c73d8add920c1ceb4185407e63a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 22
        echo "    </head>

    <body>
        
        
        <!-- Navbar -->
        

        <nav class = \"navbar navbar-default\" role=\"navigation\">
            <a class=\"navbar-brand\" href=\"";
        // line 31
        echo $this->env->getExtension('routing')->getUrl("homepage");
        echo "\">FindYourJob</a>
            
            <div class = \"container-fluid\">

                <!-- Seeker Role -->

                ";
        // line 37
        if ($this->env->getExtension('security')->isGranted("ROLE_SEEKER")) {
            // line 38
            echo "                <div class=\"navbar-header\">
                    <ul class=\"nav navbar-nav\">
                        <!--dropdown menu-->

                        <li class=\"dropdown\">
                          <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Menu <span class=\"caret\"></span></a>
                          <ul class=\"dropdown-menu dropdown-menu-right\">
                              <li><a href=\"";
            // line 45
            echo $this->env->getExtension('routing')->getUrl("seekerAccount_home");
            echo "\">Account</a></li>
                            <li><a href=\"#\">View Linked IN Profile</a></li>
                            <li><a href=\"#\">View CVs</a></li>
                            <li><a href='";
            // line 48
            echo $this->env->getExtension('routing')->getUrl("logout");
            echo "'><span>Logout ( ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " )</span></a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 50
            echo $this->env->getExtension('routing')->getUrl("jobSeeker_home");
            echo "\">View All job Seekers</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 52
            echo $this->env->getExtension('routing')->getUrl("jobRecruiter_home");
            echo "\">View All Recruiters</a></li>
                          </ul>
                        </li>

                        <li><a href='";
            // line 56
            echo $this->env->getExtension('routing')->getUrl("newsFeed_home");
            echo "'><span>Newsfeed</span></a></li>
                        <li><a href='#'><span>Vacancies</span></a></li>
                        

                        

                    </ul>
                </div>

                <div class=\"col-sm-3 col-md-3 pull-right\">
                <form class=\"navbar-form\" role=\"search\">
                    <div class=\"input-group\">
                        <input type=\"text\" class=\"form-control\" placeholder=\"Search\" name=\"q\">
                        <div class=\"input-group-btn\">
                            <button class=\"btn btn-default\" type=\"submit\"><i class=\"glyphicon glyphicon-search\"></i></button>
                        </div>
                    </div>
                </form>
                </div>

                <!-- Recruiter Role -->

                ";
        } elseif ($this->env->getExtension('security')->isGranted("ROLE_RECRUITER")) {
            // line 79
            echo "                <div class=\"navbar-header\">
                    <ul class=\"nav navbar-nav\">
                        <!--dropdown menu-->

                        <li class=\"dropdown\">
                          <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Menu <span class=\"caret\"></span></a>
                          <ul class=\"dropdown-menu dropdown-menu-right\">
                            <li><a href=\"";
            // line 86
            echo $this->env->getExtension('routing')->getUrl("companyAccount_home");
            echo "\">Account</a></li>
                              <li><a href=\"";
            // line 87
            echo $this->env->getExtension('routing')->getUrl("vacancy_home");
            echo "\">Create a vacancy</a></li>
                            <li><a href='";
            // line 88
            echo $this->env->getExtension('routing')->getUrl("logout");
            echo "'><span>Logout ( ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " )</span></a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 90
            echo $this->env->getExtension('routing')->getUrl("jobSeeker_home");
            echo "\">View All job Seekers</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 92
            echo $this->env->getExtension('routing')->getUrl("jobRecruiter_home");
            echo "\">View All Recruiters</a></li>
                          </ul>
                        </li>

                        <li><a href='";
            // line 96
            echo $this->env->getExtension('routing')->getUrl("newsFeed_home");
            echo "'><span>Newsfeed</span></a></li>
                        <li><a href='#'><span>Vacancies</span></a></li>
                        

                        

                    </ul>
                </div>

                <div class=\"col-sm-3 col-md-3 pull-right\">
                <form class=\"navbar-form\" role=\"search\">
                    <div class=\"input-group\">
                        <input type=\"text\" class=\"form-control\" placeholder=\"Search\" name=\"q\">
                        <div class=\"input-group-btn\">
                            <button class=\"btn btn-default\" type=\"submit\"><i class=\"glyphicon glyphicon-search\"></i></button>
                        </div>
                    </div>
                </form>
                </div>

               

                ";
        } else {
            // line 119
            echo "                <div class=\"navbar-header\">
                    <ul class=\"nav navbar-nav\">
                       
                            <li><a href='";
            // line 122
            echo $this->env->getExtension('routing')->getUrl("homepage_guest");
            echo "'><span>Home</span></a></li>
                            <li><a href='";
            // line 123
            echo $this->env->getExtension('routing')->getUrl("login_route");
            echo "'><span>Login</span></a></li>
                            <li><a href='";
            // line 124
            echo $this->env->getExtension('routing')->getUrl("signup_seeker");
            echo "'><span>Sign Up Seeker</span></a></li>
                            <li><a href='";
            // line 125
            echo $this->env->getExtension('routing')->getUrl("signup_recruiter");
            echo "'><span>Sign Up Recruiter</span></a></li>
                        
                    </ul>
                </div>
                ";
        }
        // line 130
        echo "                

          </div>

         

            

        </nav>

        <!-- Content -->
        <div class=\"panel panel-default\">
            <div class=\"panel-heading\">";
        // line 142
        $this->displayBlock("title", $context, $blocks);
        echo "
                <div class=\"pull-right\">";
        // line 143
        $this->displayBlock('links', $context, $blocks);
        echo "</div>
            </div>
            <div class=\"panel-body\">

                <div class='error_message'> ";
        // line 147
        echo twig_escape_filter($this->env, ((array_key_exists("form_error", $context)) ? (_twig_default_filter((isset($context["form_error"]) ? $context["form_error"] : $this->getContext($context, "form_error")), "")) : ("")), "html", null, true);
        echo " </div>
                ";
        // line 148
        $this->displayBlock('body', $context, $blocks);
        // line 151
        echo "
                ";
        // line 152
        $this->displayBlock('javascripts', $context, $blocks);
        // line 159
        echo "            </div>
        </div>
    </body>
</html>
";
        
        $__internal_f36750604337ad9b1f4a52c6da006121465e1c73d8add920c1ceb4185407e63a->leave($__internal_f36750604337ad9b1f4a52c6da006121465e1c73d8add920c1ceb4185407e63a_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_4af7f0ca740b29e00dd7a6c8af29ff898660abe892bae61751a3fb7393809730 = $this->env->getExtension("native_profiler");
        $__internal_4af7f0ca740b29e00dd7a6c8af29ff898660abe892bae61751a3fb7393809730->enter($__internal_4af7f0ca740b29e00dd7a6c8af29ff898660abe892bae61751a3fb7393809730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome Test!";
        
        $__internal_4af7f0ca740b29e00dd7a6c8af29ff898660abe892bae61751a3fb7393809730->leave($__internal_4af7f0ca740b29e00dd7a6c8af29ff898660abe892bae61751a3fb7393809730_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5c693df1b372b58c8c84ee15b3a0d18d9bc845ec3f493ca155c2f750c629f5ef = $this->env->getExtension("native_profiler");
        $__internal_5c693df1b372b58c8c84ee15b3a0d18d9bc845ec3f493ca155c2f750c629f5ef->enter($__internal_5c693df1b372b58c8c84ee15b3a0d18d9bc845ec3f493ca155c2f750c629f5ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/jobs.png"), "html", null, true);
        echo "\" />

        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/navbar.css"), "html", null, true);
        echo "\" />

        ";
        // line 15
        echo "

        ";
        // line 18
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/custom.css"), "html", null, true);
        echo "\" />

        
        ";
        
        $__internal_5c693df1b372b58c8c84ee15b3a0d18d9bc845ec3f493ca155c2f750c629f5ef->leave($__internal_5c693df1b372b58c8c84ee15b3a0d18d9bc845ec3f493ca155c2f750c629f5ef_prof);

    }

    // line 143
    public function block_links($context, array $blocks = array())
    {
        $__internal_5e5a74ea06c617c21f7d52652121653c46f2c7ef988e36afa559923912743c30 = $this->env->getExtension("native_profiler");
        $__internal_5e5a74ea06c617c21f7d52652121653c46f2c7ef988e36afa559923912743c30->enter($__internal_5e5a74ea06c617c21f7d52652121653c46f2c7ef988e36afa559923912743c30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "links"));

        
        $__internal_5e5a74ea06c617c21f7d52652121653c46f2c7ef988e36afa559923912743c30->leave($__internal_5e5a74ea06c617c21f7d52652121653c46f2c7ef988e36afa559923912743c30_prof);

    }

    // line 148
    public function block_body($context, array $blocks = array())
    {
        $__internal_0fe1ff4dfd44ea1985d5d486649ef4ac540a439d265a5ad93d3aafdc8334ac98 = $this->env->getExtension("native_profiler");
        $__internal_0fe1ff4dfd44ea1985d5d486649ef4ac540a439d265a5ad93d3aafdc8334ac98->enter($__internal_0fe1ff4dfd44ea1985d5d486649ef4ac540a439d265a5ad93d3aafdc8334ac98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 149
        echo "
                ";
        
        $__internal_0fe1ff4dfd44ea1985d5d486649ef4ac540a439d265a5ad93d3aafdc8334ac98->leave($__internal_0fe1ff4dfd44ea1985d5d486649ef4ac540a439d265a5ad93d3aafdc8334ac98_prof);

    }

    // line 152
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_bd4f327f4f95db472b9c3b866628e704a4ecabfe176e529860c1f05737c05011 = $this->env->getExtension("native_profiler");
        $__internal_bd4f327f4f95db472b9c3b866628e704a4ecabfe176e529860c1f05737c05011->enter($__internal_bd4f327f4f95db472b9c3b866628e704a4ecabfe176e529860c1f05737c05011_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 153
        echo "
                <script src=\"";
        // line 154
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/jquery-1.12.2.min.js"), "html", null, true);
        echo "\"></script>
                <script src=\"";
        // line 155
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
                <script src=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/chosen.jquery.min.js"), "html", null, true);
        echo "\"></script>

                ";
        
        $__internal_bd4f327f4f95db472b9c3b866628e704a4ecabfe176e529860c1f05737c05011->leave($__internal_bd4f327f4f95db472b9c3b866628e704a4ecabfe176e529860c1f05737c05011_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  349 => 156,  345 => 155,  341 => 154,  338 => 153,  332 => 152,  324 => 149,  318 => 148,  307 => 143,  295 => 18,  291 => 15,  286 => 12,  282 => 11,  277 => 9,  274 => 8,  268 => 7,  256 => 6,  245 => 159,  243 => 152,  240 => 151,  238 => 148,  234 => 147,  227 => 143,  223 => 142,  209 => 130,  201 => 125,  197 => 124,  193 => 123,  189 => 122,  184 => 119,  158 => 96,  151 => 92,  146 => 90,  139 => 88,  135 => 87,  131 => 86,  122 => 79,  96 => 56,  89 => 52,  84 => 50,  77 => 48,  71 => 45,  62 => 38,  60 => 37,  51 => 31,  40 => 22,  38 => 7,  34 => 6,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta name="viewport" content="width=device-width, initial-scale=1">*/
/*         <title>{% block title %}Welcome Test!{% endblock %}</title>*/
/*         {% block stylesheets %}*/
/* */
/*         <link rel="icon" type="image/x-icon" href="{{ asset('img/jobs.png') }}" />*/
/* */
/*         <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}" />*/
/*         <link rel="stylesheet" href="{{ asset('css/navbar.css') }}" />*/
/* */
/*         {#Chosen#}*/
/* */
/* */
/*         {#Custom Style#}*/
/*         <link rel="stylesheet" href="{{ asset('css/custom.css') }}" />*/
/* */
/*         */
/*         {% endblock %}*/
/*     </head>*/
/* */
/*     <body>*/
/*         */
/*         */
/*         <!-- Navbar -->*/
/*         */
/* */
/*         <nav class = "navbar navbar-default" role="navigation">*/
/*             <a class="navbar-brand" href="{{url('homepage')}}">FindYourJob</a>*/
/*             */
/*             <div class = "container-fluid">*/
/* */
/*                 <!-- Seeker Role -->*/
/* */
/*                 {% if is_granted('ROLE_SEEKER') %}*/
/*                 <div class="navbar-header">*/
/*                     <ul class="nav navbar-nav">*/
/*                         <!--dropdown menu-->*/
/* */
/*                         <li class="dropdown">*/
/*                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>*/
/*                           <ul class="dropdown-menu dropdown-menu-right">*/
/*                               <li><a href="{{url('seekerAccount_home')}}">Account</a></li>*/
/*                             <li><a href="#">View Linked IN Profile</a></li>*/
/*                             <li><a href="#">View CVs</a></li>*/
/*                             <li><a href='{{url('logout')}}'><span>Logout ( {{ app.user.username }} )</span></a></li>*/
/*                             <li role="separator" class="divider"></li>*/
/*                             <li><a href="{{url('jobSeeker_home')}}">View All job Seekers</a></li>*/
/*                             <li role="separator" class="divider"></li>*/
/*                             <li><a href="{{url('jobRecruiter_home')}}">View All Recruiters</a></li>*/
/*                           </ul>*/
/*                         </li>*/
/* */
/*                         <li><a href='{{url('newsFeed_home')}}'><span>Newsfeed</span></a></li>*/
/*                         <li><a href='#'><span>Vacancies</span></a></li>*/
/*                         */
/* */
/*                         */
/* */
/*                     </ul>*/
/*                 </div>*/
/* */
/*                 <div class="col-sm-3 col-md-3 pull-right">*/
/*                 <form class="navbar-form" role="search">*/
/*                     <div class="input-group">*/
/*                         <input type="text" class="form-control" placeholder="Search" name="q">*/
/*                         <div class="input-group-btn">*/
/*                             <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>*/
/*                         </div>*/
/*                     </div>*/
/*                 </form>*/
/*                 </div>*/
/* */
/*                 <!-- Recruiter Role -->*/
/* */
/*                 {% elseif is_granted('ROLE_RECRUITER') %}*/
/*                 <div class="navbar-header">*/
/*                     <ul class="nav navbar-nav">*/
/*                         <!--dropdown menu-->*/
/* */
/*                         <li class="dropdown">*/
/*                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>*/
/*                           <ul class="dropdown-menu dropdown-menu-right">*/
/*                             <li><a href="{{url('companyAccount_home')}}">Account</a></li>*/
/*                               <li><a href="{{url('vacancy_home')}}">Create a vacancy</a></li>*/
/*                             <li><a href='{{url('logout')}}'><span>Logout ( {{ app.user.username }} )</span></a></li>*/
/*                             <li role="separator" class="divider"></li>*/
/*                             <li><a href="{{url('jobSeeker_home')}}">View All job Seekers</a></li>*/
/*                             <li role="separator" class="divider"></li>*/
/*                             <li><a href="{{url('jobRecruiter_home')}}">View All Recruiters</a></li>*/
/*                           </ul>*/
/*                         </li>*/
/* */
/*                         <li><a href='{{url('newsFeed_home')}}'><span>Newsfeed</span></a></li>*/
/*                         <li><a href='#'><span>Vacancies</span></a></li>*/
/*                         */
/* */
/*                         */
/* */
/*                     </ul>*/
/*                 </div>*/
/* */
/*                 <div class="col-sm-3 col-md-3 pull-right">*/
/*                 <form class="navbar-form" role="search">*/
/*                     <div class="input-group">*/
/*                         <input type="text" class="form-control" placeholder="Search" name="q">*/
/*                         <div class="input-group-btn">*/
/*                             <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>*/
/*                         </div>*/
/*                     </div>*/
/*                 </form>*/
/*                 </div>*/
/* */
/*                */
/* */
/*                 {% else %}*/
/*                 <div class="navbar-header">*/
/*                     <ul class="nav navbar-nav">*/
/*                        */
/*                             <li><a href='{{url('homepage_guest')}}'><span>Home</span></a></li>*/
/*                             <li><a href='{{url('login_route')}}'><span>Login</span></a></li>*/
/*                             <li><a href='{{url('signup_seeker')}}'><span>Sign Up Seeker</span></a></li>*/
/*                             <li><a href='{{url('signup_recruiter')}}'><span>Sign Up Recruiter</span></a></li>*/
/*                         */
/*                     </ul>*/
/*                 </div>*/
/*                 {% endif %}*/
/*                 */
/* */
/*           </div>*/
/* */
/*          */
/* */
/*             */
/* */
/*         </nav>*/
/* */
/*         <!-- Content -->*/
/*         <div class="panel panel-default">*/
/*             <div class="panel-heading">{{ block('title')}}*/
/*                 <div class="pull-right">{% block links %}{% endblock %}</div>*/
/*             </div>*/
/*             <div class="panel-body">*/
/* */
/*                 <div class='error_message'> {{ form_error | default("") }} </div>*/
/*                 {% block body %}*/
/* */
/*                 {% endblock %}*/
/* */
/*                 {% block javascripts %}*/
/* */
/*                 <script src="{{ asset('js/jquery-1.12.2.min.js')}}"></script>*/
/*                 <script src="{{ asset('js/bootstrap.min.js')}}"></script>*/
/*                 <script src="{{ asset('js/chosen.jquery.min.js') }}"></script>*/
/* */
/*                 {% endblock %}*/
/*             </div>*/
/*         </div>*/
/*     </body>*/
/* </html>*/
/* */
