<?php

/* advertisement/view.html.twig */
class __TwigTemplate_78d1a2c64ec5246ca796f2102e403624e8705244b08ed0ace27c1e15bd91d08b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "advertisement/view.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_98ca6b8c8f97346f14cb017a42159fb56abe1c84a444244c8e127faef904d3f7 = $this->env->getExtension("native_profiler");
        $__internal_98ca6b8c8f97346f14cb017a42159fb56abe1c84a444244c8e127faef904d3f7->enter($__internal_98ca6b8c8f97346f14cb017a42159fb56abe1c84a444244c8e127faef904d3f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "advertisement/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_98ca6b8c8f97346f14cb017a42159fb56abe1c84a444244c8e127faef904d3f7->leave($__internal_98ca6b8c8f97346f14cb017a42159fb56abe1c84a444244c8e127faef904d3f7_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_821287067d49e87e7898a3775b87708c800a669436411f067d8845f9cdf189c2 = $this->env->getExtension("native_profiler");
        $__internal_821287067d49e87e7898a3775b87708c800a669436411f067d8845f9cdf189c2->enter($__internal_821287067d49e87e7898a3775b87708c800a669436411f067d8845f9cdf189c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Advertisement Details
";
        
        $__internal_821287067d49e87e7898a3775b87708c800a669436411f067d8845f9cdf189c2->leave($__internal_821287067d49e87e7898a3775b87708c800a669436411f067d8845f9cdf189c2_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_a50c157ac6cecab700505448b10d3d8ea2d9d61c87cf9f4f2b6e3554dc828191 = $this->env->getExtension("native_profiler");
        $__internal_a50c157ac6cecab700505448b10d3d8ea2d9d61c87cf9f4f2b6e3554dc828191->enter($__internal_a50c157ac6cecab700505448b10d3d8ea2d9d61c87cf9f4f2b6e3554dc828191_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
    <table style=\"width:50%\">
        <tr>
            <td><b>ID:</td>
            <td>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["advertisement"]) ? $context["advertisement"] : $this->getContext($context, "advertisement")), "id", array()), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td><b>Size X:</td>
            <td>";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["advertisement"]) ? $context["advertisement"] : $this->getContext($context, "advertisement")), "sizeX", array()), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td><b>Size Y:</td>
            <td>";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["advertisement"]) ? $context["advertisement"] : $this->getContext($context, "advertisement")), "sizeY", array()), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td><b>Days to Display:</td>
            <td>";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["advertisement"]) ? $context["advertisement"] : $this->getContext($context, "advertisement")), "daysToDisplay", array()), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td><b>Advertisement:</td>
            <td>
                <div class=\"btn-group\" >

                    <a href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("advertisement_file", array("id" => $this->getAttribute((isset($context["advertisement"]) ? $context["advertisement"] : $this->getContext($context, "advertisement")), "id", array()))), "html", null, true);
        echo "\"><button type=\"button\" class=\"btn btn-xs btn-success\">View Image</button></a>

                </div>
            </td>
        </tr>
    </table>

";
        
        $__internal_a50c157ac6cecab700505448b10d3d8ea2d9d61c87cf9f4f2b6e3554dc828191->leave($__internal_a50c157ac6cecab700505448b10d3d8ea2d9d61c87cf9f4f2b6e3554dc828191_prof);

    }

    public function getTemplateName()
    {
        return "advertisement/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 34,  82 => 27,  75 => 23,  68 => 19,  61 => 15,  55 => 11,  49 => 10,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* */
/* {# app/Resources/views/jobseeker/view.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     Advertisement Details*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/*     <table style="width:50%">*/
/*         <tr>*/
/*             <td><b>ID:</td>*/
/*             <td>{{advertisement.id}}</td>*/
/*         </tr>*/
/*         <tr>*/
/*             <td><b>Size X:</td>*/
/*             <td>{{advertisement.sizeX}}</td>*/
/*         </tr>*/
/*         <tr>*/
/*             <td><b>Size Y:</td>*/
/*             <td>{{advertisement.sizeY}}</td>*/
/*         </tr>*/
/*         <tr>*/
/*             <td><b>Days to Display:</td>*/
/*             <td>{{advertisement.daysToDisplay}}</td>*/
/*         </tr>*/
/*         <tr>*/
/*             <td><b>Advertisement:</td>*/
/*             <td>*/
/*                 <div class="btn-group" >*/
/* */
/*                     <a href="{{ url('advertisement_file', {'id':advertisement.id}) }}"><button type="button" class="btn btn-xs btn-success">View Image</button></a>*/
/* */
/*                 </div>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/* */
/* {% endblock %}*/
/* */
