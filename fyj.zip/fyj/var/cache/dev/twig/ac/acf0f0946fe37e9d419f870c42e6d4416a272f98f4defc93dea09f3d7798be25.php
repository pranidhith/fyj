<?php

/* default/index.html.twig */
class __TwigTemplate_f1e310ccb89971c3d298388a48be9ed3eed7d27e2983adefafcee2d9785c9643 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7c883e1cd08bc9933ad6e2749647226e50b1fb923306d2461c0186ff270ef17 = $this->env->getExtension("native_profiler");
        $__internal_a7c883e1cd08bc9933ad6e2749647226e50b1fb923306d2461c0186ff270ef17->enter($__internal_a7c883e1cd08bc9933ad6e2749647226e50b1fb923306d2461c0186ff270ef17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a7c883e1cd08bc9933ad6e2749647226e50b1fb923306d2461c0186ff270ef17->leave($__internal_a7c883e1cd08bc9933ad6e2749647226e50b1fb923306d2461c0186ff270ef17_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_91556af754d5aedf5287255320a321e269eb5907aa55852330ea8491041a609f = $this->env->getExtension("native_profiler");
        $__internal_91556af754d5aedf5287255320a321e269eb5907aa55852330ea8491041a609f->enter($__internal_91556af754d5aedf5287255320a321e269eb5907aa55852330ea8491041a609f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "Welcome to Find Your Job
";
        
        $__internal_91556af754d5aedf5287255320a321e269eb5907aa55852330ea8491041a609f->leave($__internal_91556af754d5aedf5287255320a321e269eb5907aa55852330ea8491041a609f_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_088129ee5a2d2c270e969ec3a235cab885de8a0c72c250489bf0490fdb521179 = $this->env->getExtension("native_profiler");
        $__internal_088129ee5a2d2c270e969ec3a235cab885de8a0c72c250489bf0490fdb521179->enter($__internal_088129ee5a2d2c270e969ec3a235cab885de8a0c72c250489bf0490fdb521179_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "
    <div class=\"head\">
      <div class=\"container\">
        <h1>Find Your Job - Online Job management System</h1>
        <p>
            This is an online job recruitment system
        </p>
      </div>
    </div> 

    <div class=\"top-row\">
        <div class=\"container firstlayer left\">
            <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\" data-interval=\"3000\">
                <ol class=\"carousel-indicators\">
                    <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
                    <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
                    <li data-target=\"#myCarousel\" data-slide-to=\"3\"></li>
                    <li data-target=\"#myCarousel\" data-slide-to=\"4\"></li>
                </ol>
            
                <div class=\"carousel-inner\">
              
                    <div class=\"item active\">
                        <img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/1.jpg"), "html", null, true);
        echo "\" alt=\"findYourJob\" class=\"img-responsive\" height=\"300\" width=\"1900\">
                        <div class=\"carousel-caption\">
                        <h3>Looking for jobs?</h3>
                        <p>This is the perfect place to find your future job</p>
                      </div>
                    </div>
              
                    <div class=\"item\">
                        <img src=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/2.jpg"), "html", null, true);
        echo "\" alt=\"Codos\" class=\"img-responsive\" height=\"100\" width=\"1900\">
                    </div>
                      
                    <div class=\"item\">
                        <img src=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/3.jpg"), "html", null, true);
        echo "\" alt=\"Codos\" class=\"img-responsive\" height=\"300\" width=\"1900\" >
                    </div>  

                    <div class=\"item\">
                        <img src=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/4.png"), "html", null, true);
        echo "\" alt=\"Codos\" class=\"img-responsive\" height=\"300\" width=\"1900\" >
                    </div> 
                    
                    <div class=\"item\">
                        <img src=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/5.jpg"), "html", null, true);
        echo "\" alt=\"Codos\" class=\"img-responsive\" height=\"300\" width=\"1900\" >
                    </div> 
                </div>

                <a class=\"carousel-control left\" href=\"#myCarousel\" data-slide=\"prev\">
                    <span class=\"icon-prev\"></span>
                </a>
                <a class=\"carousel-control right\" href=\"#myCarousel\" data-slide=\"next\">
                    <span class=\"icon-next\"></span>
                </a>
            </div>

        </div>
    </div>

    <div class=\"learn-more\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-md-4\">
            <h3>Advertisements</h3>
            <p>Submit your advertisements through here</p>
            <p><a href=\"#\">Advertise</a></p>
          </div>
          <div class=\"col-md-4\">
            <h3>Job Opportunities</h3>
            <p>See how the sports use and manage the available limited number of resources</p>
            <p><a href=\"/msrms/web/app_dev.php/resource/view\">Available Opportunities</a></p>
          </div>
          <div class=\"col-md-4\">
            <h3>Create accounts</h3>
            <p>See who are involved in sports, the sports they are involved in and their positions</p>
            <p><a href=\"/msrms/web/app_dev.php/player/view\">Create</a></p>
          </div>
          <div class=\"col-md-4\">
            <h3>Contacts</h3>
            <p>See the sports that are currently there at University of Moratuwa</p>
            <p><a href=\"/msrms/web/app_dev.php/sport/view\">Contact Details</a></p>
          </div>
        </div>
      </div>
    </div>


";
        
        $__internal_088129ee5a2d2c270e969ec3a235cab885de8a0c72c250489bf0490fdb521179->leave($__internal_088129ee5a2d2c270e969ec3a235cab885de8a0c72c250489bf0490fdb521179_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 53,  106 => 49,  99 => 45,  92 => 41,  81 => 33,  55 => 9,  49 => 8,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Welcome to Find Your Job*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/*     <div class="head">*/
/*       <div class="container">*/
/*         <h1>Find Your Job - Online Job management System</h1>*/
/*         <p>*/
/*             This is an online job recruitment system*/
/*         </p>*/
/*       </div>*/
/*     </div> */
/* */
/*     <div class="top-row">*/
/*         <div class="container firstlayer left">*/
/*             <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="3000">*/
/*                 <ol class="carousel-indicators">*/
/*                     <li data-target="#myCarousel" data-slide-to="0" class="active"></li>*/
/*                     <li data-target="#myCarousel" data-slide-to="1"></li>*/
/*                     <li data-target="#myCarousel" data-slide-to="2"></li>*/
/*                     <li data-target="#myCarousel" data-slide-to="3"></li>*/
/*                     <li data-target="#myCarousel" data-slide-to="4"></li>*/
/*                 </ol>*/
/*             */
/*                 <div class="carousel-inner">*/
/*               */
/*                     <div class="item active">*/
/*                         <img src="{{ asset('img/1.jpg') }}" alt="findYourJob" class="img-responsive" height="300" width="1900">*/
/*                         <div class="carousel-caption">*/
/*                         <h3>Looking for jobs?</h3>*/
/*                         <p>This is the perfect place to find your future job</p>*/
/*                       </div>*/
/*                     </div>*/
/*               */
/*                     <div class="item">*/
/*                         <img src="{{ asset('img/2.jpg') }}" alt="Codos" class="img-responsive" height="100" width="1900">*/
/*                     </div>*/
/*                       */
/*                     <div class="item">*/
/*                         <img src="{{ asset('img/3.jpg') }}" alt="Codos" class="img-responsive" height="300" width="1900" >*/
/*                     </div>  */
/* */
/*                     <div class="item">*/
/*                         <img src="{{ asset('img/4.png') }}" alt="Codos" class="img-responsive" height="300" width="1900" >*/
/*                     </div> */
/*                     */
/*                     <div class="item">*/
/*                         <img src="{{ asset('img/5.jpg') }}" alt="Codos" class="img-responsive" height="300" width="1900" >*/
/*                     </div> */
/*                 </div>*/
/* */
/*                 <a class="carousel-control left" href="#myCarousel" data-slide="prev">*/
/*                     <span class="icon-prev"></span>*/
/*                 </a>*/
/*                 <a class="carousel-control right" href="#myCarousel" data-slide="next">*/
/*                     <span class="icon-next"></span>*/
/*                 </a>*/
/*             </div>*/
/* */
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="learn-more">*/
/*       <div class="container">*/
/*         <div class="row">*/
/*           <div class="col-md-4">*/
/*             <h3>Advertisements</h3>*/
/*             <p>Submit your advertisements through here</p>*/
/*             <p><a href="#">Advertise</a></p>*/
/*           </div>*/
/*           <div class="col-md-4">*/
/*             <h3>Job Opportunities</h3>*/
/*             <p>See how the sports use and manage the available limited number of resources</p>*/
/*             <p><a href="/msrms/web/app_dev.php/resource/view">Available Opportunities</a></p>*/
/*           </div>*/
/*           <div class="col-md-4">*/
/*             <h3>Create accounts</h3>*/
/*             <p>See who are involved in sports, the sports they are involved in and their positions</p>*/
/*             <p><a href="/msrms/web/app_dev.php/player/view">Create</a></p>*/
/*           </div>*/
/*           <div class="col-md-4">*/
/*             <h3>Contacts</h3>*/
/*             <p>See the sports that are currently there at University of Moratuwa</p>*/
/*             <p><a href="/msrms/web/app_dev.php/sport/view">Contact Details</a></p>*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/* */
/* */
/* {% endblock %}*/
/* */
/* */
