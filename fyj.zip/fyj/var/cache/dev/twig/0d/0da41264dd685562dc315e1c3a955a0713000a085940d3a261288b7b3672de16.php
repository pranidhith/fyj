<?php

/* jobrecruiter/create.html.twig */
class __TwigTemplate_52cb4d8e2a1cf9f9cff470d1a81a2dbcb53d31ddffa05fdaa0ee44c81f88e594 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "jobrecruiter/create.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1bb1c10e4638bb3c8fba3a5c5e1bc26f1383dc9631a1e4e274c166377363fcc2 = $this->env->getExtension("native_profiler");
        $__internal_1bb1c10e4638bb3c8fba3a5c5e1bc26f1383dc9631a1e4e274c166377363fcc2->enter($__internal_1bb1c10e4638bb3c8fba3a5c5e1bc26f1383dc9631a1e4e274c166377363fcc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobrecruiter/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1bb1c10e4638bb3c8fba3a5c5e1bc26f1383dc9631a1e4e274c166377363fcc2->leave($__internal_1bb1c10e4638bb3c8fba3a5c5e1bc26f1383dc9631a1e4e274c166377363fcc2_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_bb87f4209a74d1580f086e25a0941b04b99b86f06424c0a3ea9088d8c7607953 = $this->env->getExtension("native_profiler");
        $__internal_bb87f4209a74d1580f086e25a0941b04b99b86f06424c0a3ea9088d8c7607953->enter($__internal_bb87f4209a74d1580f086e25a0941b04b99b86f06424c0a3ea9088d8c7607953_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Create Account
";
        
        $__internal_bb87f4209a74d1580f086e25a0941b04b99b86f06424c0a3ea9088d8c7607953->leave($__internal_bb87f4209a74d1580f086e25a0941b04b99b86f06424c0a3ea9088d8c7607953_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_aa484a50f5cf7445935dd3c60f5fb8ee87701658e9063ccca40d4313a65a7e9d = $this->env->getExtension("native_profiler");
        $__internal_aa484a50f5cf7445935dd3c60f5fb8ee87701658e9063ccca40d4313a65a7e9d->enter($__internal_aa484a50f5cf7445935dd3c60f5fb8ee87701658e9063ccca40d4313a65a7e9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "    
";
        
        $__internal_aa484a50f5cf7445935dd3c60f5fb8ee87701658e9063ccca40d4313a65a7e9d->leave($__internal_aa484a50f5cf7445935dd3c60f5fb8ee87701658e9063ccca40d4313a65a7e9d_prof);

    }

    public function getTemplateName()
    {
        return "jobrecruiter/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 11,  59 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Create Account*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}    */
/* {% endblock %}*/
