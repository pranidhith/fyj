<?php

/* jobrecruiter/view.html.twig */
class __TwigTemplate_726209ce69b92770d46e45c6090da2365dd1eacb65fa956268bd9058ed0ee069 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "jobrecruiter/view.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03bda10c0f66b9b6c82d1729ab1c07207b6029a85f8f8070ce310aee0f62b6ff = $this->env->getExtension("native_profiler");
        $__internal_03bda10c0f66b9b6c82d1729ab1c07207b6029a85f8f8070ce310aee0f62b6ff->enter($__internal_03bda10c0f66b9b6c82d1729ab1c07207b6029a85f8f8070ce310aee0f62b6ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobrecruiter/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_03bda10c0f66b9b6c82d1729ab1c07207b6029a85f8f8070ce310aee0f62b6ff->leave($__internal_03bda10c0f66b9b6c82d1729ab1c07207b6029a85f8f8070ce310aee0f62b6ff_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_3c4f98d9ed48aab90ac642883f3297fa805c1521602f292ecb596639b62b37b4 = $this->env->getExtension("native_profiler");
        $__internal_3c4f98d9ed48aab90ac642883f3297fa805c1521602f292ecb596639b62b37b4->enter($__internal_3c4f98d9ed48aab90ac642883f3297fa805c1521602f292ecb596639b62b37b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "Job Recruiter Details
";
        
        $__internal_3c4f98d9ed48aab90ac642883f3297fa805c1521602f292ecb596639b62b37b4->leave($__internal_3c4f98d9ed48aab90ac642883f3297fa805c1521602f292ecb596639b62b37b4_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_2094073dc299149cf980d4690fcfec280422c647a2c1edae5c60cb55963628a7 = $this->env->getExtension("native_profiler");
        $__internal_2094073dc299149cf980d4690fcfec280422c647a2c1edae5c60cb55963628a7->enter($__internal_2094073dc299149cf980d4690fcfec280422c647a2c1edae5c60cb55963628a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
<table style=\"width:50%\">
  <tr>
    <td><b>Name:</td>
    <td>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "name", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Company Name:</td>
    <td>";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "companyName", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Company Address:</td>
    <td>";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "companyAddress", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Email Address:</td>
    <td>";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "emailAddress", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Account Created Date:</td>
    <td>";
        // line 31
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "accCreatedDate", array()), "Y-m-d"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Account Last Accessed Date:</td>
    <td>";
        // line 35
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "accLastAccessedDate", array()), "Y-m-d"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Linked In URL:</td>
    <td>";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "linkedInURL", array()), "html", null, true);
        echo "</td>
  </tr>

  <tr>
    <td><b>LinkedIN profile:</td>
    <td>
      <div class=\"btn-group\" >

        <a href=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobRecruiter_linkedin", array("id" => $this->getAttribute((isset($context["jobRecruiter"]) ? $context["jobRecruiter"] : $this->getContext($context, "jobRecruiter")), "id", array()))), "html", null, true);
        echo "\"><button type=\"button\" class=\"btn btn-xs btn-success\">View LinkedIN Profile</button></a>

      </div>
    </td>
  </tr>
   
</table>

";
        
        $__internal_2094073dc299149cf980d4690fcfec280422c647a2c1edae5c60cb55963628a7->leave($__internal_2094073dc299149cf980d4690fcfec280422c647a2c1edae5c60cb55963628a7_prof);

    }

    public function getTemplateName()
    {
        return "jobrecruiter/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 47,  103 => 39,  96 => 35,  89 => 31,  82 => 27,  75 => 23,  68 => 19,  61 => 15,  55 => 11,  49 => 10,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* */
/* {# app/Resources/views/jobseeker/view.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Job Recruiter Details*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* <table style="width:50%">*/
/*   <tr>*/
/*     <td><b>Name:</td>*/
/*     <td>{{jobRecruiter.name}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Company Name:</td>*/
/*     <td>{{jobRecruiter.companyName}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Company Address:</td>*/
/*     <td>{{jobRecruiter.companyAddress}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Email Address:</td>*/
/*     <td>{{jobRecruiter.emailAddress}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Account Created Date:</td>*/
/*     <td>{{jobRecruiter.accCreatedDate|date('Y-m-d')}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Account Last Accessed Date:</td>*/
/*     <td>{{jobRecruiter.accLastAccessedDate|date('Y-m-d')}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Linked In URL:</td>*/
/*     <td>{{jobRecruiter.linkedInURL}}</td>*/
/*   </tr>*/
/* */
/*   <tr>*/
/*     <td><b>LinkedIN profile:</td>*/
/*     <td>*/
/*       <div class="btn-group" >*/
/* */
/*         <a href="{{ url('jobRecruiter_linkedin', {'id':jobRecruiter.id}) }}"><button type="button" class="btn btn-xs btn-success">View LinkedIN Profile</button></a>*/
/* */
/*       </div>*/
/*     </td>*/
/*   </tr>*/
/*    */
/* </table>*/
/* */
/* {% endblock %}*/
/* */
