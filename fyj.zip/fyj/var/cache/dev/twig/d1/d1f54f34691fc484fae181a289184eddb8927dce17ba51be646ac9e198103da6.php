<?php

/* jobseeker/view.html.twig */
class __TwigTemplate_7d4285c44ee4a73840f696736275c31351290e09bc2d40ddae636899c4b03ec4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "jobseeker/view.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'links' => array($this, 'block_links'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb23a7dfbe447647fb2814a64306d8a020b856e39622c16ce5fc5f129a2d7eae = $this->env->getExtension("native_profiler");
        $__internal_cb23a7dfbe447647fb2814a64306d8a020b856e39622c16ce5fc5f129a2d7eae->enter($__internal_cb23a7dfbe447647fb2814a64306d8a020b856e39622c16ce5fc5f129a2d7eae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobseeker/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cb23a7dfbe447647fb2814a64306d8a020b856e39622c16ce5fc5f129a2d7eae->leave($__internal_cb23a7dfbe447647fb2814a64306d8a020b856e39622c16ce5fc5f129a2d7eae_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_c7b0e90e02e389dd1e6454dd45f91ec4ca4601dbaafce3f03bf058a2a7468efd = $this->env->getExtension("native_profiler");
        $__internal_c7b0e90e02e389dd1e6454dd45f91ec4ca4601dbaafce3f03bf058a2a7468efd->enter($__internal_c7b0e90e02e389dd1e6454dd45f91ec4ca4601dbaafce3f03bf058a2a7468efd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "JobSeeker Details
";
        
        $__internal_c7b0e90e02e389dd1e6454dd45f91ec4ca4601dbaafce3f03bf058a2a7468efd->leave($__internal_c7b0e90e02e389dd1e6454dd45f91ec4ca4601dbaafce3f03bf058a2a7468efd_prof);

    }

    // line 9
    public function block_links($context, array $blocks = array())
    {
        $__internal_8b74697e2e85af3e0c94b5c74ac63e94bac7f3e837fc8a55647e1cd2dc4ffd26 = $this->env->getExtension("native_profiler");
        $__internal_8b74697e2e85af3e0c94b5c74ac63e94bac7f3e837fc8a55647e1cd2dc4ffd26->enter($__internal_8b74697e2e85af3e0c94b5c74ac63e94bac7f3e837fc8a55647e1cd2dc4ffd26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "links"));

        // line 10
        echo "  <div class=\"btn-group\" >
    <a href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobSeeker_update", array("id" => $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "id", array()))), "html", null, true);
        echo "\"> <button type=\"button\" class=\"btn btn-xs btn-warning\">Update Account
      </button></a>
  </div>
";
        
        $__internal_8b74697e2e85af3e0c94b5c74ac63e94bac7f3e837fc8a55647e1cd2dc4ffd26->leave($__internal_8b74697e2e85af3e0c94b5c74ac63e94bac7f3e837fc8a55647e1cd2dc4ffd26_prof);

    }

    // line 16
    public function block_body($context, array $blocks = array())
    {
        $__internal_2e54e38a4c781a8771253952023537ee9ea9e56a366be29d0d7c025b5de68381 = $this->env->getExtension("native_profiler");
        $__internal_2e54e38a4c781a8771253952023537ee9ea9e56a366be29d0d7c025b5de68381->enter($__internal_2e54e38a4c781a8771253952023537ee9ea9e56a366be29d0d7c025b5de68381_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 17
        echo "
<table style=\"width:50%\">
  <tr>
    <td><b>Name:</td>
    <td>";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "name", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Expected Salary:</td>
    <td>";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "expectedSalary", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Account Created Date:</td>
    <td>";
        // line 29
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "accCreatedDate", array()), "Y-m-d"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Account Last Accessed Date:</td>
    <td>";
        // line 33
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "accLastAccessedDate", array()), "Y-m-d"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Email Address:</td>
    <td>";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "emailAddress", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>LinkedIn URL:</td>
    <td>";
        // line 41
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "linkedInURL", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>LinkedIN profile:</td>
    <td>
      <div class=\"btn-group\" >

        <a href=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobSeeker_linkedin", array("id" => $this->getAttribute((isset($context["jobSeeker"]) ? $context["jobSeeker"] : $this->getContext($context, "jobSeeker")), "id", array()))), "html", null, true);
        echo "\"><button type=\"button\" class=\"btn btn-xs btn-primary\">View LinkedIN Profile</button></a>

      </div>
    </td>
  </tr>
   
</table>

";
        
        $__internal_2e54e38a4c781a8771253952023537ee9ea9e56a366be29d0d7c025b5de68381->leave($__internal_2e54e38a4c781a8771253952023537ee9ea9e56a366be29d0d7c025b5de68381_prof);

    }

    public function getTemplateName()
    {
        return "jobseeker/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 48,  117 => 41,  110 => 37,  103 => 33,  96 => 29,  89 => 25,  82 => 21,  76 => 17,  70 => 16,  59 => 11,  56 => 10,  50 => 9,  42 => 6,  36 => 5,  11 => 3,);
    }
}
/* */
/* {# app/Resources/views/jobseeker/view.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* JobSeeker Details*/
/* {% endblock %}*/
/* */
/* {% block links %}*/
/*   <div class="btn-group" >*/
/*     <a href="{{url('jobSeeker_update',{'id':jobSeeker.id})}}"> <button type="button" class="btn btn-xs btn-warning">Update Account*/
/*       </button></a>*/
/*   </div>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* */
/* <table style="width:50%">*/
/*   <tr>*/
/*     <td><b>Name:</td>*/
/*     <td>{{jobSeeker.name}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Expected Salary:</td>*/
/*     <td>{{jobSeeker.expectedSalary}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Account Created Date:</td>*/
/*     <td>{{jobSeeker.accCreatedDate|date('Y-m-d')}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Account Last Accessed Date:</td>*/
/*     <td>{{jobSeeker.accLastAccessedDate|date('Y-m-d')}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Email Address:</td>*/
/*     <td>{{jobSeeker.emailAddress}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>LinkedIn URL:</td>*/
/*     <td>{{jobSeeker.linkedInURL}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>LinkedIN profile:</td>*/
/*     <td>*/
/*       <div class="btn-group" >*/
/* */
/*         <a href="{{ url('jobSeeker_linkedin', {'id':jobSeeker.id}) }}"><button type="button" class="btn btn-xs btn-primary">View LinkedIN Profile</button></a>*/
/* */
/*       </div>*/
/*     </td>*/
/*   </tr>*/
/*    */
/* </table>*/
/* */
/* {% endblock %}*/
/* */
