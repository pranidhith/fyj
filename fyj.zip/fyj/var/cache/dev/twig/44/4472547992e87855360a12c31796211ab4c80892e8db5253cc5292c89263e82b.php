<?php

/* usecases/vacancyfield_home.html.twig */
class __TwigTemplate_334b946dabf899eb02f7de388b694fb383ad3d3bce9fcd06d53b11216cc8964a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "usecases/vacancyfield_home.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f1a8ffc9958c87cb3827c374a1efc16bd38ea52c07de212a345cbb300ce772a = $this->env->getExtension("native_profiler");
        $__internal_2f1a8ffc9958c87cb3827c374a1efc16bd38ea52c07de212a345cbb300ce772a->enter($__internal_2f1a8ffc9958c87cb3827c374a1efc16bd38ea52c07de212a345cbb300ce772a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "usecases/vacancyfield_home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2f1a8ffc9958c87cb3827c374a1efc16bd38ea52c07de212a345cbb300ce772a->leave($__internal_2f1a8ffc9958c87cb3827c374a1efc16bd38ea52c07de212a345cbb300ce772a_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_9e79692815f830601952b153e2c0d62d5e08f33c6bd380d0dbac2be5a42c972c = $this->env->getExtension("native_profiler");
        $__internal_9e79692815f830601952b153e2c0d62d5e08f33c6bd380d0dbac2be5a42c972c->enter($__internal_9e79692815f830601952b153e2c0d62d5e08f33c6bd380d0dbac2be5a42c972c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Add Fields
";
        
        $__internal_9e79692815f830601952b153e2c0d62d5e08f33c6bd380d0dbac2be5a42c972c->leave($__internal_9e79692815f830601952b153e2c0d62d5e08f33c6bd380d0dbac2be5a42c972c_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_f7e27df92846c2424db3300a6ba51ae1200d684d34c41a5c16627f440497d80e = $this->env->getExtension("native_profiler");
        $__internal_f7e27df92846c2424db3300a6ba51ae1200d684d34c41a5c16627f440497d80e->enter($__internal_f7e27df92846c2424db3300a6ba51ae1200d684d34c41a5c16627f440497d80e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "    
";
        
        $__internal_f7e27df92846c2424db3300a6ba51ae1200d684d34c41a5c16627f440497d80e->leave($__internal_f7e27df92846c2424db3300a6ba51ae1200d684d34c41a5c16627f440497d80e_prof);

    }

    public function getTemplateName()
    {
        return "usecases/vacancyfield_home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 11,  59 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Add Fields*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}    */
/* {% endblock %}*/
