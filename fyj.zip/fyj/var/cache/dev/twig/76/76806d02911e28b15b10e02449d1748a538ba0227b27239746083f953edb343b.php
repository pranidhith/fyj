<?php

/* security/signup.html.twig */
class __TwigTemplate_effcdc063b3b6ba985742da513710e460ccc6d1af334a1d071a36668517ef671 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "security/signup.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df807f0a6de68812b59e5327ef19eca6631aef4a13f640f4ea7fe7b8cb02ccfa = $this->env->getExtension("native_profiler");
        $__internal_df807f0a6de68812b59e5327ef19eca6631aef4a13f640f4ea7fe7b8cb02ccfa->enter($__internal_df807f0a6de68812b59e5327ef19eca6631aef4a13f640f4ea7fe7b8cb02ccfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/signup.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_df807f0a6de68812b59e5327ef19eca6631aef4a13f640f4ea7fe7b8cb02ccfa->leave($__internal_df807f0a6de68812b59e5327ef19eca6631aef4a13f640f4ea7fe7b8cb02ccfa_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_317b78527870dac0bdfa547f853e35c62f888f64619a73a4b6e18f955226c592 = $this->env->getExtension("native_profiler");
        $__internal_317b78527870dac0bdfa547f853e35c62f888f64619a73a4b6e18f955226c592->enter($__internal_317b78527870dac0bdfa547f853e35c62f888f64619a73a4b6e18f955226c592_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Sign Up
";
        
        $__internal_317b78527870dac0bdfa547f853e35c62f888f64619a73a4b6e18f955226c592->leave($__internal_317b78527870dac0bdfa547f853e35c62f888f64619a73a4b6e18f955226c592_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_2fbd4655306e44b443c173e5af8637cc4887a3d7d84672b4ef1e6b35eb1375f4 = $this->env->getExtension("native_profiler");
        $__internal_2fbd4655306e44b443c173e5af8637cc4887a3d7d84672b4ef1e6b35eb1375f4->enter($__internal_2fbd4655306e44b443c173e5af8637cc4887a3d7d84672b4ef1e6b35eb1375f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    
    ";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

    ";
        // line 13
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_2fbd4655306e44b443c173e5af8637cc4887a3d7d84672b4ef1e6b35eb1375f4->leave($__internal_2fbd4655306e44b443c173e5af8637cc4887a3d7d84672b4ef1e6b35eb1375f4_prof);

    }

    public function getTemplateName()
    {
        return "security/signup.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 13,  58 => 11,  55 => 10,  49 => 9,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* {# app/Resources/views/jobSeeker/create.html.twig #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     Sign Up*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     */
/*     {{ form_start(form) }}*/
/* */
/*     {{ form_end(form) }}*/
/* {% endblock %}*/
/* */
