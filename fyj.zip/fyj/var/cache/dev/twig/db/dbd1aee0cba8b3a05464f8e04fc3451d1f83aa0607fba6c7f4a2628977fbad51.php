<?php

/* vacancy/viewall.html.twig */
class __TwigTemplate_be6f52d747875ff699b64984db6df06f909cd86c9741834aee9e5b55e4b0e103 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "vacancy/viewall.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b57c180f3fd7caf4ba50422c0092c475fda9817184e86cf8ce0e6be5bcad3c94 = $this->env->getExtension("native_profiler");
        $__internal_b57c180f3fd7caf4ba50422c0092c475fda9817184e86cf8ce0e6be5bcad3c94->enter($__internal_b57c180f3fd7caf4ba50422c0092c475fda9817184e86cf8ce0e6be5bcad3c94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vacancy/viewall.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b57c180f3fd7caf4ba50422c0092c475fda9817184e86cf8ce0e6be5bcad3c94->leave($__internal_b57c180f3fd7caf4ba50422c0092c475fda9817184e86cf8ce0e6be5bcad3c94_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_336f6a56cc2089ceb332d76bd050f532897950d1a17091b2fb0cedf28fea780d = $this->env->getExtension("native_profiler");
        $__internal_336f6a56cc2089ceb332d76bd050f532897950d1a17091b2fb0cedf28fea780d->enter($__internal_336f6a56cc2089ceb332d76bd050f532897950d1a17091b2fb0cedf28fea780d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "All Vacancies
";
        
        $__internal_336f6a56cc2089ceb332d76bd050f532897950d1a17091b2fb0cedf28fea780d->leave($__internal_336f6a56cc2089ceb332d76bd050f532897950d1a17091b2fb0cedf28fea780d_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_fcde54f20128c5348b33a608b3dc4828c7851e91c0b7821b46cf1ce4bb5f5f52 = $this->env->getExtension("native_profiler");
        $__internal_fcde54f20128c5348b33a608b3dc4828c7851e91c0b7821b46cf1ce4bb5f5f52->enter($__internal_fcde54f20128c5348b33a608b3dc4828c7851e91c0b7821b46cf1ce4bb5f5f52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
<table width=\"100%\">
\t<tr>
        <th>ID</th>
\t\t<th>Place</th>
        <th>Position</th>
\t\t<th>Salary Given</th>
        <th>Closing Date</th>
        <th>Recruiter</th>
        <th>Interested Field</th>
    </tr>

    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["vacancies"]) ? $context["vacancies"] : $this->getContext($context, "vacancies")));
        foreach ($context['_seq'] as $context["_key"] => $context["jr"]) {
            // line 23
            echo "        <tr>
        <td>
        <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("vacancy_view", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "id", array()));
            echo "</a>
        </td>

\t\t<td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "place", array()));
            echo "
        </td>

        <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "position", array()));
            echo "
        </td>

        <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "salaryGiven", array()));
            echo "
        </td>

        <td>";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["jr"], "closingDate", array()), "Y-m-d"), "html", null, true);
            echo "
        </td>

        <td><a href=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobRecruiter_view", array("id" => $this->getAttribute($this->getAttribute($context["jr"], "getPostedVacancy", array(), "method"), "getId", array(), "method"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["jr"], "getPostedVacancy", array(), "method"), "getCompanyName", array(), "method"));
            echo "
        </td>


        <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["jr"], "getVacancyField", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "</td>


        <td>
            <div class=\"btn-group\" >

                <a href=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("apply_vacancy", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\"><button type=\"button\" class=\"btn btn-xs btn-success\">Apply</button></a>

                <a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("apply_viewAll", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\"><button type=\"button\" class=\"btn btn-xs btn-info\">View All Appications</button></a>
            </div>
        </td>

        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['jr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "
   
</table>

";
        
        $__internal_fcde54f20128c5348b33a608b3dc4828c7851e91c0b7821b46cf1ce4bb5f5f52->leave($__internal_fcde54f20128c5348b33a608b3dc4828c7851e91c0b7821b46cf1ce4bb5f5f52_prof);

    }

    public function getTemplateName()
    {
        return "vacancy/viewall.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 58,  132 => 52,  127 => 50,  118 => 44,  109 => 40,  103 => 37,  97 => 34,  91 => 31,  85 => 28,  77 => 25,  73 => 23,  69 => 22,  55 => 10,  49 => 9,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* All Vacancies*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* <table width="100%">*/
/* 	<tr>*/
/*         <th>ID</th>*/
/* 		<th>Place</th>*/
/*         <th>Position</th>*/
/* 		<th>Salary Given</th>*/
/*         <th>Closing Date</th>*/
/*         <th>Recruiter</th>*/
/*         <th>Interested Field</th>*/
/*     </tr>*/
/* */
/*     {% for jr in vacancies %}*/
/*         <tr>*/
/*         <td>*/
/*         <a href="{{url('vacancy_view',{'id':jr.id})}}">{{ jr.id|e }}</a>*/
/*         </td>*/
/* */
/* 		<td>{{ jr.place|e }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.position|e }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.salaryGiven|e }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.closingDate|date('Y-m-d') }}*/
/*         </td>*/
/* */
/*         <td><a href="{{url('jobRecruiter_view',{'id':jr.getPostedVacancy().getId()})}}">{{ jr.getPostedVacancy().getCompanyName()|e }}*/
/*         </td>*/
/* */
/* */
/*         <td>{{jr.getVacancyField().getName()}}</td>*/
/* */
/* */
/*         <td>*/
/*             <div class="btn-group" >*/
/* */
/*                 <a href="{{ url('apply_vacancy', {'id':jr.id}) }}"><button type="button" class="btn btn-xs btn-success">Apply</button></a>*/
/* */
/*                 <a href="{{ url('apply_viewAll', {'id':jr.id}) }}"><button type="button" class="btn btn-xs btn-info">View All Appications</button></a>*/
/*             </div>*/
/*         </td>*/
/* */
/*         </tr>*/
/*     {% endfor %}*/
/* */
/*    */
/* </table>*/
/* */
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
