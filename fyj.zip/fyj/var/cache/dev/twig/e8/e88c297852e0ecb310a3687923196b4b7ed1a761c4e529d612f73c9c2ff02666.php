<?php

/* jobseeker/create.html.twig */
class __TwigTemplate_e93a6114dda6a928c347c8a71ca8a8633050f6f40a63f9a535b8393ecf31b678 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "jobseeker/create.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1acac9af4d58a4e34933c5d1a69fd3e4eed0cc733b7d5bb99691cae2db83505b = $this->env->getExtension("native_profiler");
        $__internal_1acac9af4d58a4e34933c5d1a69fd3e4eed0cc733b7d5bb99691cae2db83505b->enter($__internal_1acac9af4d58a4e34933c5d1a69fd3e4eed0cc733b7d5bb99691cae2db83505b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobseeker/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1acac9af4d58a4e34933c5d1a69fd3e4eed0cc733b7d5bb99691cae2db83505b->leave($__internal_1acac9af4d58a4e34933c5d1a69fd3e4eed0cc733b7d5bb99691cae2db83505b_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_0b408a874ffdc0072b47f1044bddeaae4b5410db73c928a91d7e6a131a523d28 = $this->env->getExtension("native_profiler");
        $__internal_0b408a874ffdc0072b47f1044bddeaae4b5410db73c928a91d7e6a131a523d28->enter($__internal_0b408a874ffdc0072b47f1044bddeaae4b5410db73c928a91d7e6a131a523d28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Create Account
";
        
        $__internal_0b408a874ffdc0072b47f1044bddeaae4b5410db73c928a91d7e6a131a523d28->leave($__internal_0b408a874ffdc0072b47f1044bddeaae4b5410db73c928a91d7e6a131a523d28_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_74fd99d9c4e863524ba32b27eee12da4f4c4f3be207f4eee4359d2d60a4255fc = $this->env->getExtension("native_profiler");
        $__internal_74fd99d9c4e863524ba32b27eee12da4f4c4f3be207f4eee4359d2d60a4255fc->enter($__internal_74fd99d9c4e863524ba32b27eee12da4f4c4f3be207f4eee4359d2d60a4255fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "    
";
        
        $__internal_74fd99d9c4e863524ba32b27eee12da4f4c4f3be207f4eee4359d2d60a4255fc->leave($__internal_74fd99d9c4e863524ba32b27eee12da4f4c4f3be207f4eee4359d2d60a4255fc_prof);

    }

    public function getTemplateName()
    {
        return "jobseeker/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 11,  59 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Create Account*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}    */
/* {% endblock %}*/
