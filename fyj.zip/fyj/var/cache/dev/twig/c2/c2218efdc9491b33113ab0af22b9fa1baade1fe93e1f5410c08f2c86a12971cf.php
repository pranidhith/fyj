<?php

/* security/login.html.twig */
class __TwigTemplate_9e0276e2a4e2591f319a98df2b86a3ed43f75c50fdeabd5a4224f9ae6d2953e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 4
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 4);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c762c05da71f50fc500cdc9829b6f02428fce534179e2531688cf708dc5168c = $this->env->getExtension("native_profiler");
        $__internal_7c762c05da71f50fc500cdc9829b6f02428fce534179e2531688cf708dc5168c->enter($__internal_7c762c05da71f50fc500cdc9829b6f02428fce534179e2531688cf708dc5168c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c762c05da71f50fc500cdc9829b6f02428fce534179e2531688cf708dc5168c->leave($__internal_7c762c05da71f50fc500cdc9829b6f02428fce534179e2531688cf708dc5168c_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_b80e8e29820ad9cca7b624f9c5daf793571310150d2359faf5ef336f0ad8bb64 = $this->env->getExtension("native_profiler");
        $__internal_b80e8e29820ad9cca7b624f9c5daf793571310150d2359faf5ef336f0ad8bb64->enter($__internal_b80e8e29820ad9cca7b624f9c5daf793571310150d2359faf5ef336f0ad8bb64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "    Sign In
";
        
        $__internal_b80e8e29820ad9cca7b624f9c5daf793571310150d2359faf5ef336f0ad8bb64->leave($__internal_b80e8e29820ad9cca7b624f9c5daf793571310150d2359faf5ef336f0ad8bb64_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_f00b51b486e8afcd703fcd5f1a8385f5aeac3aea4d57af7017c18093b14dd52b = $this->env->getExtension("native_profiler");
        $__internal_f00b51b486e8afcd703fcd5f1a8385f5aeac3aea4d57af7017c18093b14dd52b->enter($__internal_f00b51b486e8afcd703fcd5f1a8385f5aeac3aea4d57af7017c18093b14dd52b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "
";
        // line 14
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 15
            echo "    <div style=\"color: red\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 17
        echo "
<form action=\"";
        // line 18
        echo $this->env->getExtension('routing')->getPath("login_check");
        echo "\" method=\"post\">

    <label for=\"username\">Username:</label>
    <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />
    <br>
    <label for=\"password\">Password:</label>
    <input type=\"password\" id=\"password\" name=\"_password\" />
    <br>
    <button type=\"submit\">login</button>

</form>
<br>
If you are a job seeker <a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getUrl("signup_seeker");
        echo "\">sign up as a job seeker</a>.
<br>
If you are a company <a href=\"";
        // line 32
        echo $this->env->getExtension('routing')->getUrl("signup_recruiter");
        echo "\">sign up as a job recruiter</a>.

";
        
        $__internal_f00b51b486e8afcd703fcd5f1a8385f5aeac3aea4d57af7017c18093b14dd52b->leave($__internal_f00b51b486e8afcd703fcd5f1a8385f5aeac3aea4d57af7017c18093b14dd52b_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 32,  87 => 30,  75 => 21,  69 => 18,  66 => 17,  60 => 15,  58 => 14,  55 => 13,  49 => 12,  41 => 7,  35 => 6,  11 => 4,);
    }
}
/* {# app/Resources/views/security/login.html.twig #}*/
/* {# ... you will probably extends your base template, like base.html.twig #}*/
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     Sign In*/
/* {% endblock %}*/
/* */
/* */
/* */
/* {% block body %}*/
/* */
/* {% if error %}*/
/*     <div style="color: red">{{ error.messageKey|trans(error.messageData, 'security') }}</div>*/
/* {% endif %}*/
/* */
/* <form action="{{ path('login_check') }}" method="post">*/
/* */
/*     <label for="username">Username:</label>*/
/*     <input type="text" id="username" name="_username" value="{{ last_username }}" />*/
/*     <br>*/
/*     <label for="password">Password:</label>*/
/*     <input type="password" id="password" name="_password" />*/
/*     <br>*/
/*     <button type="submit">login</button>*/
/* */
/* </form>*/
/* <br>*/
/* If you are a job seeker <a href="{{url('signup_seeker')}}">sign up as a job seeker</a>.*/
/* <br>*/
/* If you are a company <a href="{{url('signup_recruiter')}}">sign up as a job recruiter</a>.*/
/* */
/* {%  endblock %}*/
