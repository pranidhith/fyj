<?php

/* jobRecruiter/update.html.twig */
class __TwigTemplate_6470ed65c9475cedf89731d9dc46f8424f2d7df3f8a54da1af36e9e40652e665 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "jobRecruiter/update.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_672fe60e039d94335e56c26baf8d7028523b74c6636e840eaf73d548b40389e7 = $this->env->getExtension("native_profiler");
        $__internal_672fe60e039d94335e56c26baf8d7028523b74c6636e840eaf73d548b40389e7->enter($__internal_672fe60e039d94335e56c26baf8d7028523b74c6636e840eaf73d548b40389e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobRecruiter/update.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_672fe60e039d94335e56c26baf8d7028523b74c6636e840eaf73d548b40389e7->leave($__internal_672fe60e039d94335e56c26baf8d7028523b74c6636e840eaf73d548b40389e7_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_ecb6b9b716933d6947f5d4e4a615469598110d693f50638d7b6e58751063f464 = $this->env->getExtension("native_profiler");
        $__internal_ecb6b9b716933d6947f5d4e4a615469598110d693f50638d7b6e58751063f464->enter($__internal_ecb6b9b716933d6947f5d4e4a615469598110d693f50638d7b6e58751063f464_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Update Job Recruiter
";
        
        $__internal_ecb6b9b716933d6947f5d4e4a615469598110d693f50638d7b6e58751063f464->leave($__internal_ecb6b9b716933d6947f5d4e4a615469598110d693f50638d7b6e58751063f464_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_a82b23000acfd5da8a69b04e4191e627270025153c75184ef38ddd52de5b9bd3 = $this->env->getExtension("native_profiler");
        $__internal_a82b23000acfd5da8a69b04e4191e627270025153c75184ef38ddd52de5b9bd3->enter($__internal_a82b23000acfd5da8a69b04e4191e627270025153c75184ef38ddd52de5b9bd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "    
";
        
        $__internal_a82b23000acfd5da8a69b04e4191e627270025153c75184ef38ddd52de5b9bd3->leave($__internal_a82b23000acfd5da8a69b04e4191e627270025153c75184ef38ddd52de5b9bd3_prof);

    }

    public function getTemplateName()
    {
        return "jobRecruiter/update.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 11,  59 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/equipment/update.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Update Job Recruiter*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}    */
/* {% endblock %}*/
