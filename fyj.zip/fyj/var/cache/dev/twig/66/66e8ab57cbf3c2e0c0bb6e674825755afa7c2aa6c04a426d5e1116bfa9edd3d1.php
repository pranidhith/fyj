<?php

/* usecases/newsfeed_home.html.twig */
class __TwigTemplate_d7164340853d36e21ab4eee9e6529c156a27aaf7ab273251a54c6c594f342c15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "usecases/newsfeed_home.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd041f13bb7f3164744e3fca1af919c944a6c972697e7f64c035f44de15b595d = $this->env->getExtension("native_profiler");
        $__internal_dd041f13bb7f3164744e3fca1af919c944a6c972697e7f64c035f44de15b595d->enter($__internal_dd041f13bb7f3164744e3fca1af919c944a6c972697e7f64c035f44de15b595d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "usecases/newsfeed_home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dd041f13bb7f3164744e3fca1af919c944a6c972697e7f64c035f44de15b595d->leave($__internal_dd041f13bb7f3164744e3fca1af919c944a6c972697e7f64c035f44de15b595d_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_584a6cb81e54ac3c316b5a5d8ebd566c4f4f98eb578290c101e35a09b90caa7e = $this->env->getExtension("native_profiler");
        $__internal_584a6cb81e54ac3c316b5a5d8ebd566c4f4f98eb578290c101e35a09b90caa7e->enter($__internal_584a6cb81e54ac3c316b5a5d8ebd566c4f4f98eb578290c101e35a09b90caa7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "    All Vacancies
";
        
        $__internal_584a6cb81e54ac3c316b5a5d8ebd566c4f4f98eb578290c101e35a09b90caa7e->leave($__internal_584a6cb81e54ac3c316b5a5d8ebd566c4f4f98eb578290c101e35a09b90caa7e_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_5553b80551d74d4e4a07324abaf48643787cbfda703762aa59108e15f83c424b = $this->env->getExtension("native_profiler");
        $__internal_5553b80551d74d4e4a07324abaf48643787cbfda703762aa59108e15f83c424b->enter($__internal_5553b80551d74d4e4a07324abaf48643787cbfda703762aa59108e15f83c424b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    <table width=\"100%\">
        <tr>
            <th>ID</th>
            <th>Place</th>
            <th>Position</th>
            <th>Salary Given</th>
            <th>Closing Date</th>
            <th>Recruiter</th>
            <th>Interested Field</th>
        </tr>

        ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["newsfeeds"]) ? $context["newsfeeds"] : $this->getContext($context, "newsfeeds")));
        foreach ($context['_seq'] as $context["_key"] => $context["jr"]) {
            // line 23
            echo "            <tr>
                <td>
                    <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("vacancy_view", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "id", array()));
            echo "</a>
                </td>

                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "place", array()));
            echo "
                </td>

                <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "position", array()));
            echo "
                </td>

                <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "salaryGiven", array()));
            echo "
                </td>

                <td>";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["jr"], "closingDate", array()), "Y-m-d"), "html", null, true);
            echo "
                </td>

                <td><a href=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobRecruiter_view", array("id" => $this->getAttribute($this->getAttribute($context["jr"], "getPostedVacancy", array(), "method"), "getId", array(), "method"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["jr"], "getPostedVacancy", array(), "method"), "getCompanyName", array(), "method"));
            echo "
                </td>


                <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["jr"], "getVacancyField", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "</td>


                <td>
                    <div class=\"btn-group\" >

                        <a href=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("apply_vacancy", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\"><button type=\"button\" class=\"btn btn-xs btn-success\">Apply</button></a>

                        <a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("apply_viewAll", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\"><button type=\"button\" class=\"btn btn-xs btn-info\">View All Appications</button></a>
                    </div>
                </td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['jr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "

    </table>

";
        
        $__internal_5553b80551d74d4e4a07324abaf48643787cbfda703762aa59108e15f83c424b->leave($__internal_5553b80551d74d4e4a07324abaf48643787cbfda703762aa59108e15f83c424b_prof);

    }

    public function getTemplateName()
    {
        return "usecases/newsfeed_home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 58,  132 => 52,  127 => 50,  118 => 44,  109 => 40,  103 => 37,  97 => 34,  91 => 31,  85 => 28,  77 => 25,  73 => 23,  69 => 22,  55 => 10,  49 => 9,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     All Vacancies*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/*     <table width="100%">*/
/*         <tr>*/
/*             <th>ID</th>*/
/*             <th>Place</th>*/
/*             <th>Position</th>*/
/*             <th>Salary Given</th>*/
/*             <th>Closing Date</th>*/
/*             <th>Recruiter</th>*/
/*             <th>Interested Field</th>*/
/*         </tr>*/
/* */
/*         {% for jr in newsfeeds %}*/
/*             <tr>*/
/*                 <td>*/
/*                     <a href="{{url('vacancy_view',{'id':jr.id})}}">{{ jr.id|e }}</a>*/
/*                 </td>*/
/* */
/*                 <td>{{ jr.place|e }}*/
/*                 </td>*/
/* */
/*                 <td>{{ jr.position|e }}*/
/*                 </td>*/
/* */
/*                 <td>{{ jr.salaryGiven|e }}*/
/*                 </td>*/
/* */
/*                 <td>{{ jr.closingDate|date('Y-m-d') }}*/
/*                 </td>*/
/* */
/*                 <td><a href="{{url('jobRecruiter_view',{'id':jr.getPostedVacancy().getId()})}}">{{ jr.getPostedVacancy().getCompanyName()|e }}*/
/*                 </td>*/
/* */
/* */
/*                 <td>{{jr.getVacancyField().getName()}}</td>*/
/* */
/* */
/*                 <td>*/
/*                     <div class="btn-group" >*/
/* */
/*                         <a href="{{ url('apply_vacancy', {'id':jr.id}) }}"><button type="button" class="btn btn-xs btn-success">Apply</button></a>*/
/* */
/*                         <a href="{{ url('apply_viewAll', {'id':jr.id}) }}"><button type="button" class="btn btn-xs btn-info">View All Appications</button></a>*/
/*                     </div>*/
/*                 </td>*/
/* */
/*             </tr>*/
/*         {% endfor %}*/
/* */
/* */
/*     </table>*/
/* */
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
