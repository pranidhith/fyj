<?php

/* advertisement/create.html.twig */
class __TwigTemplate_3f6aa0960e56451dd574d4ce7ad87675c18fe3f1253855fc579a78b8298330a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "advertisement/create.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fa2c27cab68ae10daf530f931272433e29e1f03845a017b38181969d32fb192 = $this->env->getExtension("native_profiler");
        $__internal_2fa2c27cab68ae10daf530f931272433e29e1f03845a017b38181969d32fb192->enter($__internal_2fa2c27cab68ae10daf530f931272433e29e1f03845a017b38181969d32fb192_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "advertisement/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2fa2c27cab68ae10daf530f931272433e29e1f03845a017b38181969d32fb192->leave($__internal_2fa2c27cab68ae10daf530f931272433e29e1f03845a017b38181969d32fb192_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_fd6deb6482241395d1768c300e019c1c6c2665011dfc7c612b441a403aa9f746 = $this->env->getExtension("native_profiler");
        $__internal_fd6deb6482241395d1768c300e019c1c6c2665011dfc7c612b441a403aa9f746->enter($__internal_fd6deb6482241395d1768c300e019c1c6c2665011dfc7c612b441a403aa9f746_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "    Submit an Advertisement
";
        
        $__internal_fd6deb6482241395d1768c300e019c1c6c2665011dfc7c612b441a403aa9f746->leave($__internal_fd6deb6482241395d1768c300e019c1c6c2665011dfc7c612b441a403aa9f746_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_93c6ecf08cb40e2f07627501712d8b9f3453cb14b2aeb5c8ae7c4f9e4bdc6a01 = $this->env->getExtension("native_profiler");
        $__internal_93c6ecf08cb40e2f07627501712d8b9f3453cb14b2aeb5c8ae7c4f9e4bdc6a01->enter($__internal_93c6ecf08cb40e2f07627501712d8b9f3453cb14b2aeb5c8ae7c4f9e4bdc6a01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_93c6ecf08cb40e2f07627501712d8b9f3453cb14b2aeb5c8ae7c4f9e4bdc6a01->leave($__internal_93c6ecf08cb40e2f07627501712d8b9f3453cb14b2aeb5c8ae7c4f9e4bdc6a01_prof);

    }

    public function getTemplateName()
    {
        return "advertisement/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 11,  60 => 10,  55 => 9,  49 => 8,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/*     Submit an Advertisement*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ form_start(form) }}*/
/*     {{ form_widget(form) }}*/
/*     {{ form_end(form) }}*/
/* {% endblock %}*/
