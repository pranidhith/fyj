<?php

/* jobrecruiter/viewall.html.twig */
class __TwigTemplate_ea30d8c2a1d5b22bdc0116bfe36d7c2832c7cdc3eeee4523a81661a2fd99bf55 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "jobrecruiter/viewall.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb42bc863a339f08e7a53174cbd5cfac2f9046e5087edc24275b8bd205ab25b6 = $this->env->getExtension("native_profiler");
        $__internal_fb42bc863a339f08e7a53174cbd5cfac2f9046e5087edc24275b8bd205ab25b6->enter($__internal_fb42bc863a339f08e7a53174cbd5cfac2f9046e5087edc24275b8bd205ab25b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobrecruiter/viewall.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb42bc863a339f08e7a53174cbd5cfac2f9046e5087edc24275b8bd205ab25b6->leave($__internal_fb42bc863a339f08e7a53174cbd5cfac2f9046e5087edc24275b8bd205ab25b6_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_8e1af865c1baf93725fa378e8f64db112a0d65bbe3a17d3d430809a1e0307237 = $this->env->getExtension("native_profiler");
        $__internal_8e1af865c1baf93725fa378e8f64db112a0d65bbe3a17d3d430809a1e0307237->enter($__internal_8e1af865c1baf93725fa378e8f64db112a0d65bbe3a17d3d430809a1e0307237_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "All Job Recruiters
";
        
        $__internal_8e1af865c1baf93725fa378e8f64db112a0d65bbe3a17d3d430809a1e0307237->leave($__internal_8e1af865c1baf93725fa378e8f64db112a0d65bbe3a17d3d430809a1e0307237_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_60edff3858f9b31fba60b79347de54c99f7636154879ecf8cc13acaf83df1a53 = $this->env->getExtension("native_profiler");
        $__internal_60edff3858f9b31fba60b79347de54c99f7636154879ecf8cc13acaf83df1a53->enter($__internal_60edff3858f9b31fba60b79347de54c99f7636154879ecf8cc13acaf83df1a53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
<table width=\"100%\">
\t<tr>
\t\t<th>Name</th>
\t\t<th>Company Name</th>
        <th>Company Address</th>
        <th>Email Address</th>
        <th>Account Created Date</th>
        <th>Account Last Accessed Date</th>
        <th>LinkedIn URL</th>
        
    </tr>

    ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["jobRecruiters"]) ? $context["jobRecruiters"] : $this->getContext($context, "jobRecruiters")));
        foreach ($context['_seq'] as $context["_key"] => $context["jr"]) {
            // line 24
            echo "        <tr>
        <td>
        <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobRecruiter_view", array("id" => $this->getAttribute($context["jr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "name", array()));
            echo "</a>
        </td>

\t\t<td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "companyName", array()));
            echo "
        </td>

        <td>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "companyAddress", array()));
            echo "
        </td>

        <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "emailAddress", array()));
            echo "
        </td>

        <td>";
            // line 38
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["jr"], "accCreatedDate", array()), "Y-m-d"), "html", null, true);
            echo "
        </td>

        <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["jr"], "accLastAccessedDate", array()), "Y-m-d"), "html", null, true);
            echo "
        </td>

        <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["jr"], "linkedInURL", array()), "html", null, true);
            echo "
        </td>

        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['jr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "
   
</table>

";
        
        $__internal_60edff3858f9b31fba60b79347de54c99f7636154879ecf8cc13acaf83df1a53->leave($__internal_60edff3858f9b31fba60b79347de54c99f7636154879ecf8cc13acaf83df1a53_prof);

    }

    public function getTemplateName()
    {
        return "jobrecruiter/viewall.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 49,  116 => 44,  110 => 41,  104 => 38,  98 => 35,  92 => 32,  86 => 29,  78 => 26,  74 => 24,  70 => 23,  55 => 10,  49 => 9,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* All Job Recruiters*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* <table width="100%">*/
/* 	<tr>*/
/* 		<th>Name</th>*/
/* 		<th>Company Name</th>*/
/*         <th>Company Address</th>*/
/*         <th>Email Address</th>*/
/*         <th>Account Created Date</th>*/
/*         <th>Account Last Accessed Date</th>*/
/*         <th>LinkedIn URL</th>*/
/*         */
/*     </tr>*/
/* */
/*     {% for jr in jobRecruiters %}*/
/*         <tr>*/
/*         <td>*/
/*         <a href="{{url('jobRecruiter_view',{'id':jr.id})}}">{{ jr.name|e }}</a>*/
/*         </td>*/
/* */
/* 		<td>{{ jr.companyName|e }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.companyAddress|e }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.emailAddress|e }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.accCreatedDate|date('Y-m-d') }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.accLastAccessedDate|date('Y-m-d') }}*/
/*         </td>*/
/* */
/*         <td>{{ jr.linkedInURL}}*/
/*         </td>*/
/* */
/*         </tr>*/
/*     {% endfor %}*/
/* */
/*    */
/* </table>*/
/* */
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
