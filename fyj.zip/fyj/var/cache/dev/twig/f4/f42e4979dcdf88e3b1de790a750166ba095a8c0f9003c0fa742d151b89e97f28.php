<?php

/* jobseeker/viewall.html.twig */
class __TwigTemplate_743d4fb3e5e81e9beb20221f992c726365756f9a7a928fcfa03bdc203eb6ebda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "jobseeker/viewall.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cdc2aa457db3162aa2a6fc65ccc1602d44a70919bb669fce8f029de60dca9abd = $this->env->getExtension("native_profiler");
        $__internal_cdc2aa457db3162aa2a6fc65ccc1602d44a70919bb669fce8f029de60dca9abd->enter($__internal_cdc2aa457db3162aa2a6fc65ccc1602d44a70919bb669fce8f029de60dca9abd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "jobseeker/viewall.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cdc2aa457db3162aa2a6fc65ccc1602d44a70919bb669fce8f029de60dca9abd->leave($__internal_cdc2aa457db3162aa2a6fc65ccc1602d44a70919bb669fce8f029de60dca9abd_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_26c118ab9dd53234968c121cd85ebe5b675cd7867850e886b9171cd8ad4822e3 = $this->env->getExtension("native_profiler");
        $__internal_26c118ab9dd53234968c121cd85ebe5b675cd7867850e886b9171cd8ad4822e3->enter($__internal_26c118ab9dd53234968c121cd85ebe5b675cd7867850e886b9171cd8ad4822e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "All Job Seekers
";
        
        $__internal_26c118ab9dd53234968c121cd85ebe5b675cd7867850e886b9171cd8ad4822e3->leave($__internal_26c118ab9dd53234968c121cd85ebe5b675cd7867850e886b9171cd8ad4822e3_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_855ef3e683a67e2543165aa4f0d23711ead640a7a5bbda3b700ec06f37836071 = $this->env->getExtension("native_profiler");
        $__internal_855ef3e683a67e2543165aa4f0d23711ead640a7a5bbda3b700ec06f37836071->enter($__internal_855ef3e683a67e2543165aa4f0d23711ead640a7a5bbda3b700ec06f37836071_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
<table width=\"100%\">
\t<tr>
\t\t<th>Name</th>
\t\t<th>Expected Salary</th>
        <th>LinkedIn URL</th>
        <th>Email Address</th>
        <th>Account Created Date</th>
        <th>Account Last Accessed Date</th>
        
    </tr>

    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["jobSeekers"]) ? $context["jobSeekers"] : $this->getContext($context, "jobSeekers")));
        foreach ($context['_seq'] as $context["_key"] => $context["js"]) {
            // line 23
            echo "        <tr>
        <td>
        <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobSeeker_view", array("id" => $this->getAttribute($context["js"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["js"], "name", array()));
            echo "</a>
        </td>

\t\t<td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["js"], "expectedSalary", array()));
            echo "
        </td>

        <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["js"], "linkedInURL", array()));
            echo "
        </td>

        <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["js"], "emailAddress", array()));
            echo "
        </td>

        <td>";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["js"], "accCreatedDate", array()), "Y-m-d"), "html", null, true);
            echo "
        </td>

        <td>";
            // line 40
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["js"], "accLastAccessedDate", array()), "Y-m-d"), "html", null, true);
            echo "
        </td>

        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['js'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "
   
</table>

";
        
        $__internal_855ef3e683a67e2543165aa4f0d23711ead640a7a5bbda3b700ec06f37836071->leave($__internal_855ef3e683a67e2543165aa4f0d23711ead640a7a5bbda3b700ec06f37836071_prof);

    }

    public function getTemplateName()
    {
        return "jobseeker/viewall.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 45,  109 => 40,  103 => 37,  97 => 34,  91 => 31,  85 => 28,  77 => 25,  73 => 23,  69 => 22,  55 => 10,  49 => 9,  41 => 5,  35 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/default/new.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* All Job Seekers*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* <table width="100%">*/
/* 	<tr>*/
/* 		<th>Name</th>*/
/* 		<th>Expected Salary</th>*/
/*         <th>LinkedIn URL</th>*/
/*         <th>Email Address</th>*/
/*         <th>Account Created Date</th>*/
/*         <th>Account Last Accessed Date</th>*/
/*         */
/*     </tr>*/
/* */
/*     {% for js in jobSeekers %}*/
/*         <tr>*/
/*         <td>*/
/*         <a href="{{url('jobSeeker_view',{'id':js.id})}}">{{ js.name|e }}</a>*/
/*         </td>*/
/* */
/* 		<td>{{ js.expectedSalary|e }}*/
/*         </td>*/
/* */
/*         <td>{{ js.linkedInURL|e }}*/
/*         </td>*/
/* */
/*         <td>{{ js.emailAddress|e }}*/
/*         </td>*/
/* */
/*         <td>{{ js.accCreatedDate|date('Y-m-d') }}*/
/*         </td>*/
/* */
/*         <td>{{ js.accLastAccessedDate|date('Y-m-d') }}*/
/*         </td>*/
/* */
/*         </tr>*/
/*     {% endfor %}*/
/* */
/*    */
/* </table>*/
/* */
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
