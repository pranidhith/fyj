<?php

/* vacancy/view.html.twig */
class __TwigTemplate_2b520aeae4f4a9f9785346673be985576b575bceb7ef2d23f467d8cfaad40485 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "vacancy/view.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8db612b6ffc52c17ba6a9146380bf9c3310dbe4fe060cfc1a5fb07a84d94163c = $this->env->getExtension("native_profiler");
        $__internal_8db612b6ffc52c17ba6a9146380bf9c3310dbe4fe060cfc1a5fb07a84d94163c->enter($__internal_8db612b6ffc52c17ba6a9146380bf9c3310dbe4fe060cfc1a5fb07a84d94163c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vacancy/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8db612b6ffc52c17ba6a9146380bf9c3310dbe4fe060cfc1a5fb07a84d94163c->leave($__internal_8db612b6ffc52c17ba6a9146380bf9c3310dbe4fe060cfc1a5fb07a84d94163c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_dbec448afc09af596ccac62bbdf44052a6e7a0a31a3546e79443fd178f67ed6d = $this->env->getExtension("native_profiler");
        $__internal_dbec448afc09af596ccac62bbdf44052a6e7a0a31a3546e79443fd178f67ed6d->enter($__internal_dbec448afc09af596ccac62bbdf44052a6e7a0a31a3546e79443fd178f67ed6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "Vacancy Details
";
        
        $__internal_dbec448afc09af596ccac62bbdf44052a6e7a0a31a3546e79443fd178f67ed6d->leave($__internal_dbec448afc09af596ccac62bbdf44052a6e7a0a31a3546e79443fd178f67ed6d_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_51def3c417901961f7d869d0dee4fc4ebe3bcbdea9709b1900504dac7e83889a = $this->env->getExtension("native_profiler");
        $__internal_51def3c417901961f7d869d0dee4fc4ebe3bcbdea9709b1900504dac7e83889a->enter($__internal_51def3c417901961f7d869d0dee4fc4ebe3bcbdea9709b1900504dac7e83889a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
<table style=\"width:50%\">
  <tr>
    <td><b>Place:</td>
    <td>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "place", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Positon:</td>
    <td>";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "position", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Salary Given:</td>
    <td>";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "salaryGiven", array()), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Closing Date:</td>
    <td>";
        // line 27
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "closingDate", array()), "Y-m-d"), "html", null, true);
        echo "</td>
  </tr>
  <tr>
    <td><b>Recruiter:</td>
    <td><a href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getUrl("jobRecruiter_view", array("id" => $this->getAttribute($this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "getPostedVacancy", array(), "method"), "getId", array(), "method"))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "getPostedVacancy", array(), "method"), "getCompanyName", array(), "method"));
        echo "</td>
  </tr>
  <tr>
    <td><b>Interested Field:</td>
    <td>";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["vacancy"]) ? $context["vacancy"] : $this->getContext($context, "vacancy")), "getVacancyField", array(), "method"), "getName", array(), "method"), "html", null, true);
        echo "</td>  </tr>
  <tr>
   
</table>

";
        
        $__internal_51def3c417901961f7d869d0dee4fc4ebe3bcbdea9709b1900504dac7e83889a->leave($__internal_51def3c417901961f7d869d0dee4fc4ebe3bcbdea9709b1900504dac7e83889a_prof);

    }

    public function getTemplateName()
    {
        return "vacancy/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 35,  89 => 31,  82 => 27,  75 => 23,  68 => 19,  61 => 15,  55 => 11,  49 => 10,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* */
/* {# app/Resources/views/vacancy/view.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}*/
/* Vacancy Details*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* <table style="width:50%">*/
/*   <tr>*/
/*     <td><b>Place:</td>*/
/*     <td>{{vacancy.place}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Positon:</td>*/
/*     <td>{{vacancy.position}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Salary Given:</td>*/
/*     <td>{{vacancy.salaryGiven}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Closing Date:</td>*/
/*     <td>{{vacancy.closingDate|date('Y-m-d')}}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Recruiter:</td>*/
/*     <td><a href="{{url('jobRecruiter_view',{'id':vacancy.getPostedVacancy().getId()})}}">{{ vacancy.getPostedVacancy().getCompanyName()|e }}</td>*/
/*   </tr>*/
/*   <tr>*/
/*     <td><b>Interested Field:</td>*/
/*     <td>{{vacancy.getVacancyField().getName()}}</td>  </tr>*/
/*   <tr>*/
/*    */
/* </table>*/
/* */
/* {% endblock %}*/
/* */
