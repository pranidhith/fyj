<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appTestUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appTestUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/a')) {
            if (0 === strpos($pathinfo, '/advertisement')) {
                // advertisement_home
                if (rtrim($pathinfo, '/') === '/advertisement') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'advertisement_home');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\AdvertisementController::indexAction',  '_route' => 'advertisement_home',);
                }

                // advertisement_create
                if ($pathinfo === '/advertisement/create') {
                    return array (  '_controller' => 'AppBundle\\Controller\\AdvertisementController::createAction',  '_route' => 'advertisement_create',);
                }

            }

            if (0 === strpos($pathinfo, '/apply')) {
                // apply_vacancy
                if (preg_match('#^/apply/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'apply_vacancy')), array (  '_controller' => 'AppBundle\\Controller\\ApplyController::applyAction',));
                }

                if (0 === strpos($pathinfo, '/apply/view')) {
                    // apply_view
                    if (preg_match('#^/apply/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'apply_view')), array (  '_controller' => 'AppBundle\\Controller\\ApplyController::viewAction',));
                    }

                    // apply_viewAll
                    if (0 === strpos($pathinfo, '/apply/viewall') && preg_match('#^/apply/viewall/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'apply_viewAll')), array (  '_controller' => 'AppBundle\\Controller\\ApplyController::viewAllAction',));
                    }

                }

            }

        }

        // event_file
        if (preg_match('#^/(?P<id>[^/]++)/file$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'event_file')), array (  '_controller' => 'AppBundle\\Controller\\ApplyController::fileViewAction',));
        }

        // company_home
        if ($pathinfo === '/company/account') {
            return array (  '_controller' => 'AppBundle\\Controller\\CompanyController::accountAction',  '_route' => 'company_home',);
        }

        if (0 === strpos($pathinfo, '/advertisement')) {
            if (0 === strpos($pathinfo, '/advertisement/view')) {
                // advertisement_view
                if (preg_match('#^/advertisement/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'advertisement_view')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::viewAction',));
                }

                // advertisement_viewAll
                if ($pathinfo === '/advertisement/view') {
                    return array (  '_controller' => 'AppBundle\\Controller\\CompanyController::viewallAction',  '_route' => 'advertisement_viewAll',);
                }

            }

            // advertisement_update
            if (0 === strpos($pathinfo, '/advertisement/update') && preg_match('#^/advertisement/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'advertisement_update')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::updateAction',));
            }

        }

        // advertisement_file
        if (preg_match('#^/(?P<id>[^/]++)/image$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'advertisement_file')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::adViewAction',));
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // homepage_guest
        if ($pathinfo === '/home') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexGuestAction',  '_route' => 'homepage_guest',);
        }

        // task_success
        if ($pathinfo === '/success') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::successAction',  '_route' => 'task_success',);
        }

        if (0 === strpos($pathinfo, '/job')) {
            if (0 === strpos($pathinfo, '/jobrecruiter')) {
                // jobRecruiter_home
                if (rtrim($pathinfo, '/') === '/jobrecruiter') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'jobRecruiter_home');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\JobRecruiterController::indexAction',  '_route' => 'jobRecruiter_home',);
                }

                // jobRecruiter_create
                if ($pathinfo === '/jobrecruiter/create') {
                    return array (  '_controller' => 'AppBundle\\Controller\\JobRecruiterController::createAction',  '_route' => 'jobRecruiter_create',);
                }

                if (0 === strpos($pathinfo, '/jobrecruiter/view')) {
                    // jobRecruiter_view
                    if (preg_match('#^/jobrecruiter/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'jobRecruiter_view')), array (  '_controller' => 'AppBundle\\Controller\\JobRecruiterController::viewAction',));
                    }

                    // jobRecruiter_viewAll
                    if ($pathinfo === '/jobrecruiter/view') {
                        return array (  '_controller' => 'AppBundle\\Controller\\JobRecruiterController::viewallAction',  '_route' => 'jobRecruiter_viewAll',);
                    }

                }

                // jobRecruiter_update
                if (0 === strpos($pathinfo, '/jobrecruiter/update') && preg_match('#^/jobrecruiter/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'jobRecruiter_update')), array (  '_controller' => 'AppBundle\\Controller\\JobRecruiterController::updateAction',));
                }

                // jobRecruiter_linkedin
                if (0 === strpos($pathinfo, '/jobrecruiter/linkedin') && preg_match('#^/jobrecruiter/linkedin/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'jobRecruiter_linkedin')), array (  '_controller' => 'AppBundle\\Controller\\JobRecruiterController::linkedInAction',));
                }

            }

            if (0 === strpos($pathinfo, '/jobseeker')) {
                // jobSeeker_home
                if (rtrim($pathinfo, '/') === '/jobseeker') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'jobSeeker_home');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\JobSeekerController::indexAction',  '_route' => 'jobSeeker_home',);
                }

                // jobSeeker_create
                if ($pathinfo === '/jobseeker/create') {
                    return array (  '_controller' => 'AppBundle\\Controller\\JobSeekerController::createAction',  '_route' => 'jobSeeker_create',);
                }

                if (0 === strpos($pathinfo, '/jobseeker/view')) {
                    // jobSeeker_view
                    if (preg_match('#^/jobseeker/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'jobSeeker_view')), array (  '_controller' => 'AppBundle\\Controller\\JobSeekerController::viewAction',));
                    }

                    // jobSeeker_viewAll
                    if ($pathinfo === '/jobseeker/view') {
                        return array (  '_controller' => 'AppBundle\\Controller\\JobSeekerController::viewallAction',  '_route' => 'jobSeeker_viewAll',);
                    }

                }

                // jobSeeker_update
                if (0 === strpos($pathinfo, '/jobseeker/update') && preg_match('#^/jobseeker/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'jobSeeker_update')), array (  '_controller' => 'AppBundle\\Controller\\JobSeekerController::updateAction',));
                }

                // jobSeeker_linkedin
                if (0 === strpos($pathinfo, '/jobseeker/linkedin') && preg_match('#^/jobseeker/linkedin/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'jobSeeker_linkedin')), array (  '_controller' => 'AppBundle\\Controller\\JobSeekerController::linkedInAction',));
                }

            }

        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // login_route
                if ($pathinfo === '/login') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginAction',  '_route' => 'login_route',);
                }

                // login_check
                if ($pathinfo === '/login_check') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginCheckAction',  '_route' => 'login_check',);
                }

            }

            // logout
            if ($pathinfo === '/logout') {
                return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'logout',);
            }

        }

        if (0 === strpos($pathinfo, '/recruiter/log')) {
            if (0 === strpos($pathinfo, '/recruiter/login')) {
                // loginRec_route
                if ($pathinfo === '/recruiter/login') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginRecAction',  '_route' => 'loginRec_route',);
                }

                // loginRec_check
                if ($pathinfo === '/recruiter/login_check') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginCheckRecAction',  '_route' => 'loginRec_check',);
                }

            }

            // logoutRec
            if ($pathinfo === '/recruiter/logout') {
                return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::logoutRecAction',  '_route' => 'logoutRec',);
            }

        }

        if (0 === strpos($pathinfo, '/signup')) {
            // signup_seeker
            if ($pathinfo === '/signup/seeker') {
                return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::signupSeekerAction',  '_route' => 'signup_seeker',);
            }

            // signup_recruiter
            if ($pathinfo === '/signup/recruiter') {
                return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::signupRecruiterAction',  '_route' => 'signup_recruiter',);
            }

        }

        if (0 === strpos($pathinfo, '/vacancy')) {
            // vacancy_home
            if (rtrim($pathinfo, '/') === '/vacancy') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'vacancy_home');
                }

                return array (  '_controller' => 'AppBundle\\Controller\\VacancyController::indexAction',  '_route' => 'vacancy_home',);
            }

            // vacancy_create
            if ($pathinfo === '/vacancy/create') {
                return array (  '_controller' => 'AppBundle\\Controller\\VacancyController::createAction',  '_route' => 'vacancy_create',);
            }

            if (0 === strpos($pathinfo, '/vacancy/view')) {
                // vacancy_view
                if (preg_match('#^/vacancy/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'vacancy_view')), array (  '_controller' => 'AppBundle\\Controller\\VacancyController::viewAction',));
                }

                // vacancy_viewAll
                if ($pathinfo === '/vacancy/view') {
                    return array (  '_controller' => 'AppBundle\\Controller\\VacancyController::viewallAction',  '_route' => 'vacancy_viewAll',);
                }

            }

            // vacancy_update
            if (0 === strpos($pathinfo, '/vacancy/update') && preg_match('#^/vacancy/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'vacancy_update')), array (  '_controller' => 'AppBundle\\Controller\\VacancyController::updateAction',));
            }

            // vacancy_addField
            if (rtrim($pathinfo, '/') === '/vacancyfield') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'vacancy_addField');
                }

                return array (  '_controller' => 'AppBundle\\Controller\\VacancyFieldController::addfieldAction',  '_route' => 'vacancy_addField',);
            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
