<?php

namespace Tests\AppBundle\Controller;

use AppBundle\Entity\JobSeeker;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class JobSeekerControllerTest extends WebTestCase
{
    public function testCreate()
    {
        //$seeker = new JobSeeker();

        $repository = $this->getDoctrine()
            ->getRepository('AppBundle:JobSeeker');
        $jobSeekers = $repository->findAll();

        $client = static::createClient();

        //$crawler = $client->request('GET', '/');

        $this->assertEquals(null, $jobSeekers);

    }
}
